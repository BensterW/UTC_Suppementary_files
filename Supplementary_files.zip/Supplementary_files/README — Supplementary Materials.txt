README — Supplementary Materials

Article: Unpacking Teacher Collaboration: Validation of Measurement Models Using Exploratory Structural Equation Modeling
Waldejer B., Jensen M.T., & Solheim O.J.

1. Overview

This folder contains R scripts, data, and supplementary documentation used in the analyses reported in the article.

The materials are provided to ensure transparency and reproducibility of all analyses.

2. R scripts

The folder “R-scripts and data” contains five R scripts. The scripts are designed to be run sequentially:

1_Data.R
Data import, descriptive statistics, correlation plots, and preliminary analyses.
2_EFA_PA_EGA.R
Exploratory factor analyses, parallel analysis, and EGA.
3_ESEMs_CS.R
Cross-sectional exploratory structural equation models.
4_MInvar_ICC_Rel.R
Measurement invariance testing (cross-sectional and longitudinal), ICCs, and reliability analyses.
5_ESEM_Long.R
Longitudinal ESEM analyses.
Script dependencies
Script 1 imports the dataset and must be executed before other scripts if data have not been preloaded manually.
The remaining scripts can be run independently, provided that required data objects are available in the environment.
Objects are not shared across scripts beyond data frames.
Execution notes

It is recommended to run code sequentially within scripts rather than executing entire scripts at once, as console output may be extensive and partially truncated.

3. Data

The dataset “utc_data” is included in the folder “R-scripts and data”.

If the folder structure is unchanged after download, data will be automatically loaded when running Script 1.

4. Software requirements

The scripts use the native pipe operator (|>). Therefore, R version 4.1.0 or later is required.

A basic understanding of R and structural equation modeling is assumed.

Some scripts include Norwegian characters; UTF-8 encoding is recommended to ensure correct display. Encoding instructions are provided at the beginning of Script 1.

5. Working directory

No manual setting of the working directory is required, provided that the original folder structure is preserved.

The function setsource() from the Misty package is used to automatically set the working directory based on the script location.

6. Codebook

Item wording, variable descriptions and excluded items log are provided in:

“Supplementary_files/utc_codebook.pdf”

7. Error reporting and correspondence

Readers who identify errors in the code, analyses, or conclusions are encouraged to contact the authors. Scientific progress depends on the identification and correction of errors, which facilitates continuous improvement and methodological refinement.

Corresponding author: benjamin.waldejer@uis.no

8. Data reuse

The dataset may be reused for further research provided that the original publication is properly cited. Users are encouraged to contact the authors regarding intended reuse, as additional information and supplementary data (including additional variables and waves of measurement) may be available upon request.

9. Session information

The following R environment was used for the analyses reported in the article:
R version 4.4.1 (2024-06-14 ucrt)
Platform: x86_64-w64-mingw32/x64
Running under: Windows 11 x64 (build 26100)

Matrix products: default


locale:
[1] C

time zone: Europe/Oslo
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] ordinal_2025.12-29   data.table_1.17.8    GPArotation_2025.3-1 EGAnet_2.3.0         discnorm_0.2.1       misty_0.8.1          corrplot_0.95       
 [8] psych_2.6.1          lubridate_1.9.4      forcats_1.0.1        stringr_1.6.0        dplyr_1.1.4          purrr_1.0.4          readr_2.1.6         
[15] tidyr_1.3.1          tibble_3.2.1         ggplot2_4.0.2        tidyverse_2.0.0      readxl_1.4.5         semPlot_1.1.6        semTools_0.5-7      
[22] lavaan_0.6-19       

loaded via a namespace (and not attached):
  [1] splines_4.4.1                norm_1.0-11.1                cellranger_1.1.0             R.oo_1.27.1                  XML_3.99-0.18               
  [6] rpart_4.1.23                 lifecycle_1.0.5              Rdpack_2.6.4                 StanHeaders_2.32.10          mirt_1.44.0                 
 [11] globals_0.19.0               lattice_0.22-7               MASS_7.3-65                  rockchalk_1.8.157            backports_1.5.0             
 [16] magrittr_2.0.3               rmarkdown_2.30               openxlsx_4.2.8               Hmisc_5.2-3                  otel_0.2.0                  
 [21] tmvnsim_1.0-2                qgraph_1.9.8                 zip_2.3.2                    sessioninfo_1.2.3            pkgbuild_1.4.8              
 [26] pbapply_1.7-4                minqa_1.2.8                  RColorBrewer_1.1-3           multcomp_1.4-29              abind_1.4-8                 
 [31] audio_0.1-11                 quadprog_1.5-8               R.utils_2.13.0               kappalab_0.4-12              nnet_7.3-19                 
 [36] TH.data_1.1-5                sandwich_3.1-1               jtools_2.3.1                 circlize_0.4.17              inline_0.3.21               
 [41] listenv_0.10.0               testthat_3.2.3               vegan_2.6-10                 arm_1.14-4                   parallelly_1.46.1           
 [46] permute_0.9-10               codetools_0.2-20             tidyselect_1.2.1             gmm_1.9-1                    shape_1.4.6.1               
 [51] bayesplot_1.15.0             farver_2.1.2                 lme4_1.1-37                  broom.mixed_0.2.9.6          ic.infer_1.1-7              
 [56] matrixStats_1.5.0            stats4_4.4.1                 base64enc_0.1-3              jsonlite_2.0.0               progressr_0.18.0            
 [61] Formula_1.2-5                survival_3.8-3               emmeans_2.0.1                tools_4.4.1                  ChiBarSq.DiffTest_0.0.0.9000
 [66] Rcpp_1.0.14                  glue_1.8.0                   mnormt_2.1.1                 gridExtra_2.3                xfun_0.52                   
 [71] mgcv_1.9-1                   numDeriv_2016.8-1.1          withr_3.0.2                  loo_2.9.0                    fastmap_1.2.0               
 [76] beepr_2.0                    GGally_2.4.0                 boot_1.3-30                  digest_0.6.37                mi_1.2                      
 [81] timechange_0.3.0             R6_2.6.1                     estimability_1.5.1           colorspace_2.1-1             gtools_3.9.5                
 [86] lpSolve_5.6.23               jpeg_0.1-11                  R.methodsS3_1.8.2            generics_0.1.4               corpcor_1.6.10              
 [91] htmlwidgets_1.6.4            SimDesign_2.19.2             ggstats_0.12.0               pkgconfig_2.0.3              sem_3.1-16                  
 [96] gtable_0.3.6                 S7_0.2.1                     furrr_0.3.1                  htmltools_0.5.8.1            brio_1.1.5                  
[101] carData_3.0-6                blavaan_0.5-8                scales_1.4.0                 tmvtnorm_1.7                 png_0.1-8                   
[106] reformulas_0.4.4             knitr_1.51                   rstudioapi_0.18.0            tzdb_0.5.0                   reshape2_1.4.4              
[111] checkmate_2.3.2              coda_0.19-4.1                statnet.common_4.11.0        nlme_3.1-168                 curl_6.2.2                  
[116] nloptr_2.2.1                 zoo_1.8-14                   GlobalOptions_0.1.3          parallel_4.4.1               nonnest2_0.5-8              
[121] foreign_0.8-90               pillar_1.11.1                grid_4.4.1                   vctrs_0.6.5                  OpenMx_2.21.13              
[126] ucminf_1.2.2                 xtable_1.8-4                 Deriv_4.2.0                  cluster_2.1.8.1              dcurver_0.9.2               
[131] htmlTable_2.4.3              evaluate_1.0.5               pbivnorm_0.6.0               mvtnorm_1.3-3                cli_3.6.5                   
[136] kutils_1.73                  compiler_4.4.1               rlang_1.1.6                  restriktor_0.6-30            rstantools_2.6.0            
[141] future.apply_1.20.1          fdrtool_1.2.18               plyr_1.8.9                   stringi_1.8.7                rstan_2.32.7                
[146] pander_0.6.6                 network_1.19.0               QuickJSR_1.7.0               nleqslv_3.3.5                lisrelToR_0.3               
[151] CompQuadForm_1.4.3           V8_6.0.3                     Matrix_1.7-0                 hms_1.1.4                    glasso_1.11                 
[156] future_1.69.0                kernlab_0.9-33               rbibutils_2.3                igraph_2.1.4                 broom_1.0.12                
[161] RcppParallel_5.1.10         