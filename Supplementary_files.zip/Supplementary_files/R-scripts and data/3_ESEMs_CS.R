# Supplemental material for the article:
# "Unpacking Teacher Collaboration: Validation of Measurement Models Using
# Exploratory Structural Equation Modeling" by Waldejer B., Jensen M. T., 
# Solheim O. J.

# Scripts written by Waldejer B.
# For feedback or questions please send queries to the corresponding author's
# email: benjamin.waldejer@uis.no

# Script 3 ----------------------------------------------------------------
# Information

# This script includes:
# 1. Cross-sectional Exploratory Structural Equation Models. Measurement models
# 2. ESEMs with outcomes
# 3. ESEMs: nomological network
# 4. CFA comparisons
# 5. Discrimination: Supervisory support & collaborative leadership

# NB. This script is very large, running the whole script at once is not 
# recommended. Instead we recommend marking each section and run one at a time.

# Note that the warnings from lavaan show respondents that did not complete T1 
# (T2 respondents). Therefore we can ignore those warnings.

# Packages ----------------------------------------------------------------

library(tidyverse)
library(psych)
library(GPArotation)
library(lavaan)
library(semPlot)
library(data.table)


# 1. ESEMs ----------------------------------------------------------------
# Syntax for ESEM is based on the work by Mateus Silvestrin. Explanation of
# method and process can be found at: 
# https://msilvestrin.me/post/esem/
# Note that the syntax has been modified as part of this project.

########### Types of collaboration model
ty_select <- select(utc_data, 
                    tt1_ty1, tt1_ty2,
                    tt1_ty3, 
                    tt1_ty5, tt1_ty8, tt1_ty7, 
                    tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10
)


ty_efa_poly <- polychoric(ty_select)$rho

ety_1 <- fa(ty_efa_poly, 
             nfactors = 3, 
             rotate = "oblimin", 
             fm = "wls"
)

print(ety_1, cut = 0.3, digits = 2) 

esem_ty <- select(utc_data, 
                  tt1_ty1, tt1_ty2,
                  tt1_ty3, 
                  tt1_ty5, tt1_ty8, tt1_ty7, 
                  tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10)


esem_ty

esem_ty <- rename(esem_ty, 
                  "x1" = tt1_ty1,
                  "x2" = tt1_ty2,
                  "x3" = tt1_ty3,
                  "x4" = tt1_ty5,
                  "x5" = tt1_ty8,
                  "x6" = tt1_ty7,    
                  "x7" = tt1_ty9.1,
                  "x8" = tt1_ty9.3,
                  "x9" = tt1_ty9.4,
                  "x10"= tt1_ty10
)

# Checking the data
head(esem_ty)

# Creating loadings data table
data.table::setDT
esem_loadingsty <- data.table(matrix(round(ety_1$loadings, 2), # extracting rotated loadings
                                     nrow = 10, ncol = 3))

names(esem_loadingsty) <- c("F1", "F2", "F3")
esem_loadingsty$item <- paste0("x", c(1:10))

esem_loadingsty <- melt(esem_loadingsty, "item", variable.name = "latent")

esem_loadingsty

# Setting anchors
anchorsty <- c(F1 = "x3", F2 = "x6", F3 = "x9")

# Make esem model function
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
}

# Create the ESEM model syntax
esem_modelty <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty)


# Fit the ESEM model with outcome variable
esem_fit_ty <- cfa(esem_modelty, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap", # option for bootstrapped SEs
                   # bootstrap = 1000, # Note that this makes estimation very slow
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust" # optional
)

summary(esem_fit_ty, fit.measures = TRUE, standardized = TRUE)

semPlot::semPaths(esem_fit_ty, "std", 
                  layout = "tree", 
                  intercepts = F, 
                  residuals = T, 
                  nDigits = 2, 
                  label.cex = 1, 
                  edge.label.cex=.95, 
                  fade = F
                  
)

############# Related constructs ESEM
rel_select <- select(utc_data, 
                     tt1_cu1.1:tt1_cu2,
                     tt1_le1.1,
                     tt1_le1.3,
                     tt1_le1.4,
                     tt1_le2,
                     tt1_cc2:tt1_cc4, tt1_cc6
)


rel_poly <- polychoric(rel_select)$rho

ty_rel_efa <- fa(rel_poly, 
                  nfactors = 3, 
                  rotate = "oblimin", 
                  fm = "wls"
)

print(ty_rel_efa, cut = 0.3, digits = 2) 

esem_rel <- select(utc_data, 
                   tt1_cu1.1:tt1_cu2,
                   tt1_le1.1,
                   tt1_le1.3,
                   tt1_le1.4,
                   tt1_le2,
                   tt1_cc2:tt1_cc4, tt1_cc6)


esem_rel

esem_rel <- rename(esem_rel, 
                   "x1" = tt1_cu1.1,
                   "x2" = tt1_cu1.2,
                   "x3" = tt1_cu1.3,
                   "x4" = tt1_cu2,
                   "x5" = tt1_le1.1,
                   "x6" = tt1_le1.3,    
                   "x7" = tt1_le1.4,
                   "x8" = tt1_le2,
                   "x9" = tt1_cc2,
                   "x10"= tt1_cc3,
                   "x11"= tt1_cc4,
                   "x12"= tt1_cc6
)

# Checking the data
head(esem_rel)

# Creating loadings data table
data.table::setDT
esem_loadingsrel <- data.table(matrix(round(ty_rel_efa$loadings, 2),
                                      nrow = 12, ncol = 3))

names(esem_loadingsrel) <- c("F1", "F2", "F3")
esem_loadingsrel$item <- paste0("x", c(1:12))

esem_loadingsrel <- melt(esem_loadingsrel, "item", variable.name = "latent")

esem_loadingsrel

# Setting anchors
anchorsrel <- c(F1 = "x11", F2 = "x3", F3 = "x7")

# Make esem model function
make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all syntax
  paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
}

# Create the ESEM model syntax
esem_modelrel <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel)

# Fit the ESEM model with outcome variable
esem_fit_rel <- cfa(esem_modelrel, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "Wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), 
                    # se = "bootstrap", # option for bootstrapped SEs
                    # bootstrap = 1000, # Note that this makes estimation very (understatement...) slow
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust" # optional
)

summary(esem_fit_rel, fit.measures = TRUE, standardized = TRUE)

semPlot::semPaths(esem_fit_rel, "std", 
                  layout = "tree", 
                  intercepts = F, 
                  residuals = T, 
                  nDigits = 2, 
                  label.cex = 1, 
                  edge.label.cex=.95, 
                  fade = F
                  
)

# 2.1 ESEMs of Types with outcomes ----------------------------------------
# NB. Each dimension of BAT12 must be modelled separately due to convergence issues.
ty_select <- select(utc_data,
                    tt1_ty1, tt1_ty2,
                    tt1_ty3, 
                    tt1_ty5, tt1_ty8, tt1_ty7, 
                    tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10
)


ty_efa_poly <- polychoric(ty_select)$rho

ety_1 <- fa(ty_efa_poly, 
            nfactors = 3, 
            rotate = "oblimin", 
            fm = "wls"
)

print(ety_1, cut = 0.3, digits = 2) 

esem_ty <- select(utc_data,
                  tt1_ty1, tt1_ty2,
                  tt1_ty3, 
                  tt1_ty5, tt1_ty8, tt1_ty7, 
                  tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10)

esem_ty

esem_ty <- rename(esem_ty, 
                  "x1" = tt1_ty1,
                  "x2" = tt1_ty2,
                  "x3" = tt1_ty3,
                  "x4" = tt1_ty5,
                  "x5" = tt1_ty8,
                  "x6" = tt1_ty7,    
                  "x7" = tt1_ty9.1,
                  "x8" = tt1_ty9.3,
                  "x9" = tt1_ty9.4,
                  "x10"= tt1_ty10
)

# Checking the data
head(esem_ty)

# Creating loadings data table
data.table::setDT
esem_loadingsty <- data.table(matrix(round(ety_1$loadings, 2),
                                     nrow = 10, ncol = 3))

names(esem_loadingsty) <- c("F1", "F2", "F3")
esem_loadingsty$item <- paste0("x", c(1:10))

esem_loadingsty <- melt(esem_loadingsty, "item", variable.name = "latent")

esem_loadingsty

# Setting anchors
anchorsty <- c(F1 = "x3", F2 = "x6", F3 = "x9")

####### Burnout Assessment tool (BAT) as outcome

# Modifying the function to include structural paths for BAT
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable BAT to the model
  outcome_syntax <- "Exh =~ tt1_ba.1 + tt1_ba.2 + tt1_ba.3 \n         # Switch dimension without # to run each dimension of BAT
                     #  Md  =~ tt1_ba.4 + tt1_ba.5 + tt1_ba.6 \n      # Switch dimension without # to run each dimension of BAT
                     # Cog =~ tt1_ba.7 + tt1_ba.8 + tt1_ba.9 \n       # Switch dimension without # to run each dimension of BAT
                     # Emo =~ tt1_ba.10 + tt1_ba.11 + tt1_ba.12 \n    # Switch dimension without # to run each dimension of BAT
                      "
  
  # Specify structural paths for association with outcomes
  association_syntax <- "Exh ~ F1 + F2 + F3 \n" # Ad appropriate name of dimension from above ("outcome_syntax") see example below
                      # Md ~ F1 + F2 + F3 \n"  # Example
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelty_bat <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty_bat)

# Adding BAT variables to the dataset
esem_ty <- cbind(esem_ty, utc_data[, c("tt1_ba.1", "tt1_ba.2", "tt1_ba.3",
                                               "tt1_ba.4", "tt1_ba.5", "tt1_ba.6",
                                               "tt1_ba.7", "tt1_ba.8", "tt1_ba.9",
                                               "tt1_ba.10", "tt1_ba.11", "tt1_ba.12"
)])

# Fit the ESEM model with outcome variable
esem_fit_ty_bat <- cfa(esem_modelty_bat, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   missing = "pairwise",
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap",
                   # bootstrap = 1000,
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust"
)



summary(esem_fit_ty_bat, fit.measures = TRUE, standardized = TRUE)

####### Emotional exhaustion (MBI) as outcome

# Modified function to include structural paths for Emotional Exhaustion
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable Emotional Exhaustion to the model
  outcome_syntax <- "Emo =~ tt1_ee.1 + tt1_ee.2 + tt1_ee.3 + tt1_ee.4 + tt1_ee.5 \n"
  
  # Specify structural paths for association with outcomes
  association_syntax <- "Emo ~ F1 + F2 + F3 \n" 
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelty_mbi <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty_mbi)

# Adding mbi variables to the dataset
esem_ty <- cbind(esem_ty, utc_data[, c("tt1_ee.1", "tt1_ee.2", "tt1_ee.3", "tt1_ee.4", "tt1_ee.5"
)])

# Fit the ESEM model with outcome variable
esem_fit_ty_mbi <- cfa(esem_modelty_mbi, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap",
                   # bootstrap = 1000,
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust"
)

summary(esem_fit_ty_mbi, fit.measures = TRUE, standardized = TRUE)

######## Engagement UWES3 as outcome

# Modifying the function to include structural paths for uwes3
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable uwes3 to the model
  outcome_syntax <- "UWES3 =~ tt1_en.1 + tt1_en.2 + tt1_en.6\n"
  
  
  # Specify structural paths for associations with outcomes
  association_syntax <- "UWES3 ~ F1 + F2 + F3 \n"
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelty_uwes <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty_uwes)

# Adding engagement variables to the dataset
esem_ty <- cbind(esem_ty, utc_data[, c("tt1_en.1", "tt1_en.2", "tt1_en.6"
)])

# Fit the ESEM model with outcome variable
esem_fit_ty_uwes <- cfa(esem_modelty_uwes, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap",
                   # bootstrap = 1000,
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust"
)

summary(esem_fit_ty_uwes, fit.measures = TRUE, standardized = TRUE)


# 2.2 ESEMs of Related constructs with outcomes ---------------------------

rel_select <- select(utc_data, 
                     tt1_cu1.1:tt1_cu2,
                     tt1_le1.1,
                     tt1_le1.3,
                     tt1_le1.4,
                     tt1_le2,
                     tt1_cc2:tt1_cc4, tt1_cc6
)


rel_poly <- polychoric(rel_select)$rho

ty_rel_efa <- fa(rel_poly, 
                 nfactors = 3, 
                 rotate = "oblimin", 
                 fm = "wls"
)

print(ty_rel_efa, cut = 0.3, digits = 2) 

esem_rel <- select(utc_data,
                   tt1_cu1.1:tt1_cu2,
                   tt1_le1.1,
                   tt1_le1.3,
                   tt1_le1.4,
                   tt1_le2,
                   tt1_cc2:tt1_cc4, tt1_cc6)


esem_rel

esem_rel <- rename(esem_rel, 
                   "x1" = tt1_cu1.1,
                   "x2" = tt1_cu1.2,
                   "x3" = tt1_cu1.3,
                   "x4" = tt1_cu2,
                   "x5" = tt1_le1.1,
                   "x6" = tt1_le1.3,    
                   "x7" = tt1_le1.4,
                   "x8" = tt1_le2,
                   "x9" = tt1_cc2,
                   "x10"= tt1_cc3,
                   "x11"= tt1_cc4,
                   "x12"= tt1_cc6
)

# Checking the data
head(esem_rel)

# Creating loadings data table
data.table::setDT
esem_loadingsrel <- data.table(matrix(round(ty_rel_efa$loadings, 2),
                                      nrow = 12, ncol = 3))

names(esem_loadingsrel) <- c("F1", "F2", "F3")
esem_loadingsrel$item <- paste0("x", c(1:12))

esem_loadingsrel <- melt(esem_loadingsrel, "item", variable.name = "latent")

esem_loadingsrel

# Setting anchors
anchorsrel <- c(F1 = "x11", F2 = "x3", F3 = "x7")


######## Burnout Assessment tool as outcome

# Modifying the function to include structural paths for BAT
make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable BAT to the model
  outcome_syntax <- " Exh =~ tt1_ba.1 + tt1_ba.2 + tt1_ba.3 \n
                       Md  =~ tt1_ba.4 + tt1_ba.5 + tt1_ba.6 \n
                      Cog =~ tt1_ba.7 + tt1_ba.8 + tt1_ba.9 \n
                      Emo =~ tt1_ba.10 + tt1_ba.11 + tt1_ba.12 \n
                      "
  
  # Specify structural paths for association
  association_syntax <- "Exh + Md + Cog + Emo ~ F1 + F2 + F3 \n" 
  
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelrel_bat <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel_bat)

# Adding bat variables to the dataset
esem_rel <- cbind(esem_rel, utc_data[, c("tt1_ba.1", "tt1_ba.2", "tt1_ba.3",
                                                      "tt1_ba.4", "tt1_ba.5", "tt1_ba.6",
                                                      "tt1_ba.7", "tt1_ba.8", "tt1_ba.9",
                                                      "tt1_ba.10", "tt1_ba.11", "tt1_ba.12"
)])

# Fit the ESEM model with outcome variable
esem_fit_rel_bat <- cfa(esem_modelrel_bat, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "Wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                    # se = "bootstrap",
                    # bootstrap = 1000,
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust"
)

summary(esem_fit_rel_bat, fit.measures = TRUE, standardized = TRUE)

########## Emotional Exhaustion (MBI) as outcome

# Modifying the function to include structural paths for EE
make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  ## Add outcome variable BAT to the model
  outcome_syntax <- "Emo =~ tt1_ee.1 + tt1_ee.2 + tt1_ee.3 + tt1_ee.4 + tt1_ee.5 \n"
  
  # Specify structural paths for association
  association_syntax <- "Emo ~ F1 + F2 + F3 \n"  
  
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelrel_mbi <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel_mbi)

# Adding mbi variables to the dataset
esem_rel <- cbind(esem_rel, utc_data[, c("tt1_ee.1", "tt1_ee.2", "tt1_ee.3", "tt1_ee.4", "tt1_ee.5"
)])

# Fit the ESEM model with outcome variable
esem_fit_rel_mbi <- cfa(esem_modelrel_mbi, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "Wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                    # se = "bootstrap",
                    # bootstrap = 1000,
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust"
)

summary(esem_fit_rel_mbi, fit.measures = TRUE, standardized = TRUE)

######### Engagement - Uwes3 as outcome

make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  ## Add outcome variable to the model
  outcome_syntax <- "UWES3 =~ tt1_en.1 + tt1_en.2 + tt1_en.6\n"
  
  # Specify structural paths for association
  association_syntax <- "UWES3 ~ F1 + F2 + F3 \n"  
  
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, association_syntax)
}

# Create the ESEM model syntax
esem_modelrel_uwes <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel_uwes)

# Adding engagement variables to the dataset
esem_rel <- cbind(esem_rel, utc_data[, c("tt1_en.1", "tt1_en.2", "tt1_en.6"
)])

# Fit the ESEM model with outcome variable
esem_fit_rel_uwes <- cfa(esem_modelrel_uwes, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "Wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                    # se = "bootstrap",
                    # bootstrap = 1000,
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust"
)

summary(esem_fit_rel_uwes, fit.measures = TRUE, standardized = TRUE)


# 3.1 ESEMs Nomological Network -------------------------------------------
# Collaboration types

# Note that we are reusing the data table with items, loadings and anchors from
# above (2.1 ESEMs)

########### Time pressure
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable Time pressure to the model
  outcome_syntax <- "Time_pressure =~ tt1_wl.1 + tt1_wl.2 + tt1_wl.3 + tt1_wl.4 + tt1_wl.5\n"
  
  
  # Specify structural paths for associations
  concurrent_syntax <- "Time_pressure ~ F1 + F2 + F3 \n"
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, concurrent_syntax)
}

# Create the ESEM model syntax
esem_modelty_tp <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty_tp)

# Adding time pressure variables to the dataset
esem_ty <- cbind(esem_ty, utc_data[, c("tt1_wl.1", "tt1_wl.2", "tt1_wl.3", "tt1_wl.4", "tt1_wl.5"
)])

# Fit the ESEM model with outcome variable
esem_fit_ty_tp <- cfa(esem_modelty_tp, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap",
                   # bootstrap = 1000,
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust"
)

summary(esem_fit_ty_tp, fit.measures = TRUE, standardized = TRUE)

############## Collegial support, shared goals and values (collective culture) 
make_esem_model <- function (loadings_dt, anchorsty) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable CS and CC vars to the model
  outcome_syntax <- "Collegial_support =~ tt1_co1.1 + tt1_co1.2 + tt1_co1.3\n
                     Collective_culture =~ tt1_col1.1 + tt1_col1.2 + tt1_col1.3\n
  "
  
  
  # Specify structural paths for associations
  concurrent_syntax <- "Collegial_support + Collective_culture ~ F1 + F2 + F3 \n"
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, concurrent_syntax)
}

# Create the ESEM model syntax
esem_modelty_cs_cc <- make_esem_model(esem_loadingsty, anchorsty)

# Print the model syntax
writeLines(esem_modelty_cs_cc)

# Adding collegial support and collective culture variables to the dataset
esem_ty <- cbind(esem_ty, utc_data[, c("tt1_col1.1", "tt1_col1.2", "tt1_col1.3",
                                               "tt1_co1.1", "tt1_co1.2", "tt1_co1.3"
)])

# Fit the ESEM model with outcome variable
esem_fit_ty_cs_cc <- cfa(esem_modelty_cs_cc, 
                   data = esem_ty,  
                   std.lv = TRUE, 
                   estimator = "wlsmv", 
                   estimator.args = list(ESEM = TRUE),
                   control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                   # se = "bootstrap",
                   # bootstrap = 1000,
                   ordered = TRUE,
                   parameterization = "theta",
                   # se = "robust"
)

summary(esem_fit_ty_cs_cc, fit.measures = TRUE, standardized = TRUE)

modindices(esem_fit_ty_cs_cc)



# 3.2 ESEMs Nomological Network -------------------------------------------
# Related constructs

# Note that we are reusing the data table with itesms, loadings and anchors from
# above (2.2 ESEMs)

########### Time Pressure
make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable Time pressure to the model
  outcome_syntax <- "Time_pressure =~ tt1_wl.1 + tt1_wl.2 + tt1_wl.3 + tt1_wl.4 + tt1_wl.5\n"
  
  
  # Specify structural paths for associations
  concurrent_syntax <- "Time_pressure ~ F1 + F2 + F3 \n"
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, concurrent_syntax)
}

# Create the ESEM model syntax
esem_modelrel_tp <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel_tp)

# Adding time pressure variables to the dataset
esem_rel <- cbind(esem_rel, utc_data[, c("tt1_wl.1", "tt1_wl.2", "tt1_wl.3", "tt1_wl.4", "tt1_wl.5"
)])

# Fit the ESEM model with outcome variable
esem_fit_rel_tp <- cfa(esem_modelrel_tp, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                    # se = "bootstrap",
                    # bootstrap = 1000,
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust"
)

summary(esem_fit_rel_tp, fit.measures = TRUE, standardized = TRUE)

########### Collegial support, shared goals and values (collective culture) 
make_esem_model <- function (loadings_dt, anchorsrel) {
  
  # Mark anchors
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Add outcome variable CC and cc vars to the model
  outcome_syntax <- "Collegial_support =~ tt1_co1.1 + tt1_co1.2 + tt1_co1.3\n
                     Collective_culture =~ tt1_col1.1 + tt1_col1.2 + tt1_col1.3\n
  "
  
  
  # Specify structural paths for associations
  concurrent_syntax <- "Collegial_support + Collective_culture ~ F1 + F2 + F3 \n"
  
  # Combine everything
  paste(measurement_syntax, outcome_syntax, concurrent_syntax)
}

# Create the ESEM model syntax
esem_modelrel_cs_cc <- make_esem_model(esem_loadingsrel, anchorsrel)

# Print the model syntax
writeLines(esem_modelrel_cs_cc)

# Adding CS and cc variables to the dataset
esem_rel <- cbind(esem_rel, utc_data[, c("tt1_col1.1", "tt1_col1.2", "tt1_col1.3",
                                                 "tt1_co1.1", "tt1_co1.2", "tt1_co1.3"
)])

# Fit the ESEM model with outcome variable
esem_fit_rel_cs_cc <- cfa(esem_modelrel_cs_cc, 
                    data = esem_rel,  
                    std.lv = TRUE, 
                    estimator = "wlsmv", 
                    estimator.args = list(ESEM = TRUE),
                    control = list(iter.max = 1000, rel.tol = 1e-5), # adjusting the optimizer for stability
                    # se = "bootstrap",
                    # bootstrap = 1000,
                    ordered = TRUE,
                    parameterization = "theta",
                    # se = "robust"
)

summary(esem_fit_rel_cs_cc, fit.measures = TRUE, standardized = TRUE)



# 4. CFA Comparisons ------------------------------------------------------

######### Collaboration types
types_mod <- '
                # Measurement model
                F1 =~ tt1_ty1 + tt1_ty2 + tt1_ty3
                F2 =~ tt1_ty5 + tt1_ty7 + tt1_ty8
                F3 =~ tt1_ty9.1 + tt1_ty9.3 + tt1_ty9.4 + tt1_ty10
  '

types_cfa_fit <- sem(types_mod, 
                     data = utc_data, 
                     ordered = TRUE,
                     estimator = "WLSMV",
                     parameterization = "theta",
)


summary(types_cfa_fit, fit.measures = T, standardized = T, rsquare=TRUE)

# Vizualise
semPlot::semPaths(types_cfa_fit, "std", 
                  layout = "tree", 
                  intercepts = F, 
                  residuals = T, 
                  nDigits = 2, 
                  label.cex = 1, 
                  edge.label.cex=.95, 
                  fade = F
                  
)

######### Collaboration types T2
types_mod_t2 <- '
                # Measurement model
                F1 =~ tt2_ty1 + tt2_ty2 + tt2_ty3
                F2 =~ tt2_ty5 + tt2_ty7 + tt2_ty8
                F3 =~ tt2_ty9.1 + tt2_ty9.3 + tt2_ty9.4 + tt2_ty10
  '

types_cfa_fit_t2 <- sem(types_mod_t2, 
                     data = utc_data, 
                     ordered = TRUE,
                     estimator = "WLSMV",
                     parameterization = "theta",
)


summary(types_cfa_fit_t2, fit.measures = T, standardized = T, rsquare=TRUE)


########## Related constructs
rel_cfa_mod <- '
                # Measurement model
                F1 =~ tt1_cu1.1 + tt1_cu1.2 + tt1_cu1.3 + tt1_cu2
                F2 =~ tt1_le1.1 + tt1_le1.3 + tt1_le1.4 + tt1_le2
                F3 =~ tt1_cc2 + tt1_cc3 + tt1_cc4 + tt1_cc6
                
'

rel_cfa_mod_fit <- sem(rel_cfa_mod, 
                       data = utc_data, 
                       ordered = TRUE,
                       estimator = "WLSMV",
                       parameterization = "theta",
)


summary(rel_cfa_mod_fit, fit.measures = T, standardized = T, rsquare=TRUE)

# Vizualise
semPlot::semPaths(rel_cfa_mod_fit, "std", 
                  layout = "tree", 
                  intercepts = F, 
                  residuals = T, 
                  nDigits = 2, 
                  label.cex = 1, 
                  edge.label.cex=.95, 
                  fade = F
                  
)


# 5. Discrimination -------------------------------------------------------
# Supervisory support (Skaalvik & Skaalvik) and collaborative leadership (Waldejer et al.)


leader_role_disc <- select(utc_data, tt1_le1.1,
                           tt1_le1.3,
                           tt1_le1.4,
                           tt1_le2, 
                           tt1_le4.1:tt1_le4.5)
Col_des_polych_cor_lr_disc <- polychoric(leader_role_disc)$rho

leader_role_disc_mod <- fa(Col_des_polych_cor_lr_disc, 
                           nfactors = 2, 
                           rotate = "none", 
                           fm = "wls"
)

print(leader_role_disc_mod, cut = 0.3, digits = 2)

# EFA shows that there is clear overlap here. However, this does not automatically 
# mean redundancy. checking inter-item and inter-set correlations. 

##########   Checking inter-item and inter-set correlations

# computing correlations
# Load required package

# Select items from both scales
items_le <- utc_data |> 
  select(tt1_le1.1, tt1_le1.3, tt1_le1.4, tt1_le2,
         tt1_le4.1, tt1_le4.2, tt1_le4.3, tt1_le4.4, tt1_le4.5)

# Compute the correlation matrix
cor_matrix <- cor(items_le, use = "pairwise.complete.obs")

# View the matrix
round(cor_matrix, 2)

round(cor_matrix, 2) |> 
  (\(x) { x[upper.tri(x)] <- NA; x })()

########## Cross-scale correlations

# Define item names per scale
scale1_items <- c("tt1_le1.1", "tt1_le1.3", "tt1_le1.4", "tt1_le2")
scale2_items <- c("tt1_le4.1", "tt1_le4.2", "tt1_le4.3", "tt1_le4.4", "tt1_le4.5")

# Subset the relevant parts of the matrix
cross_cor <- cor_matrix[scale1_items, scale2_items]

# View rounded cross-scale correlations
round(cross_cor, 2)


summary(as.vector(cross_cor))

# Clearly there is shared variance, but still distinction between scales. 
# This is in line with the theoretical distinction proposed in the article.