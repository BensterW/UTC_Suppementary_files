# Supplemental material for the article:
# "Unpacking Teacher Collaboration: Validation of Measurement Models Using
# Exploratory Structural Equation Modeling" by Waldejer B., Jensen M. T., 
# Solheim O. J.

# Scripts written by Waldejer B.
# For feedback or questions please send queries to the corresponding author's
# email: benjamin.waldejer@uis.no

# Script 5 ----------------------------------------------------------------
# Information

# This script includes:
# 1. Longitudinal ESEMs Multidimensional

# Packages ----------------------------------------------------------------

library(readxl)
library(tidyverse)
library(semTools)
library(lavaan)
library(psych)
library(data.table)


# 1. Longitudinal ESEM Multidim. ------------------------------------------

# Collapsing categories in order to avoid convergence issues.
T1_T2_mod <- utc_data  |> 
  mutate(
    # Collapse 1 and 2 into 2 for all items at T1 and T2
    across(
      .cols = c(tt1_ty1:tt1_ty10, tt2_ty1:tt2_ty10),
      .fns = ~ case_when(
        .x %in% c(1, 2) ~ 2,
        TRUE ~ as.numeric(.x)
      ))
  )

# Collaboration Types
# Step 1: Perform EFA on T1 Data to obtain loadings


ty.efa_t1 <- select(T1_T2_mod, 
                    tt1_ty1, tt1_ty2,
                    tt1_ty3, 
                    tt1_ty5, tt1_ty8, tt1_ty7, 
                    tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10)

ty.efa_t1_poly <- polychoric(ty.efa_t1)$rho

ty.efa_t1 <- fa(ty.efa_t1_poly, 
                nfactors = 3, 
                rotate = "oblimin", 
                fm = "wls"
)


print(ty.efa_t1, cut = 0.3, digits = 2)

# Step 2: Perform EFA on T2 Data to obtain loadings
ty.efa_t2 <- select(T1_T2_mod, 
                    tt2_ty1, tt2_ty2,
                    tt2_ty3, 
                    tt2_ty5, tt2_ty8, tt2_ty7, 
                    tt2_ty9.1, tt2_ty9.3, tt2_ty9.4, tt2_ty10)


ty.efa_t2_poly <- polychoric(ty.efa_t2)$rho

ty.efa_t2 <- fa(ty.efa_t2_poly, 
                nfactors = 3, 
                rotate = "oblimin", 
                fm = "wls"
)

# Step 3: Select both T1 and T2 variables for the ESEM model
esem_ty_t1_t2 <- select(T1_T2_mod, 
                        tt1_ty1, tt1_ty2,
                        tt1_ty3, 
                        tt1_ty5, tt1_ty8, tt1_ty7, 
                        tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10, # T1 Variables
                        tt2_ty1, tt2_ty2,
                        tt2_ty3, 
                        tt2_ty5, tt2_ty8, tt2_ty7, 
                        tt2_ty9.1, tt2_ty9.3, tt2_ty9.4, tt2_ty10 # T2 Variables  
)

# Step 4: Rename the variables for consistency in the model (T1 and T2)
esem_ty_t1_t2 <- rename(esem_ty_t1_t2, 
                        "x1_T1" = tt1_ty1,
                        "x2_T1" = tt1_ty2,
                        "x3_T1" = tt1_ty3,
                        "x4_T1" = tt1_ty5,
                        "x5_T1" = tt1_ty7,
                        "x6_T1" = tt1_ty8,
                        "x7_T1" = tt1_ty9.1,
                        "x8_T1" = tt1_ty9.3,
                        "x9_T1" = tt1_ty9.4,
                        "x10_T1"= tt1_ty10,
                        "x1_T2" = tt2_ty1,
                        "x2_T2" = tt2_ty2,
                        "x3_T2" = tt2_ty3,
                        "x4_T2" = tt2_ty5,
                        "x5_T2" = tt2_ty7,
                        "x6_T2" = tt2_ty8,
                        "x7_T2" = tt2_ty9.1,
                        "x8_T2" = tt2_ty9.3,
                        "x9_T2" = tt2_ty9.4,
                        "x10_T2"= tt2_ty10
)

# Step 5: Prepare the loadings table for both T1 and T2
# Loadings from T1 EFA
esem_loadings_t1 <- data.table(matrix(round(ty.efa_t1$loadings, 2),
                                      nrow = 10, ncol = 3))

# Loadings from T2 EFA
esem_loadings_t2 <- data.table(matrix(round(ty.efa_t2$loadings, 2),
                                      nrow = 10, ncol = 3))

# Name the loadings for clarity
names(esem_loadings_t1) <- c("F1_T1", "F2_T1", "F3_T1")
names(esem_loadings_t2) <- c("F1_T2", "F2_T2", "F3_T2")

# Set the item labels for both T1 and T2
esem_loadings_t1$item <- paste0("x", c(1:10), "_T1")
esem_loadings_t2$item <- paste0("x", c(1:10), "_T2")


# Reshape the data to long format for easier model creation
esem_loadings_t1 <- melt(esem_loadings_t1, "item", variable.name = "latent")
esem_loadings_t2 <- melt(esem_loadings_t2, "item", variable.name = "latent")

# Combine T1 and T2 loadings
esem_loadings <- rbind(esem_loadings_t1, esem_loadings_t2)

# Step 6: Define anchors for T1 and T2 (example: F1_T1 = x3_T1, F1_T2 = x3_T2)
anchorsty <- c(F1_T1 = "x5_T1", F2_T1 = "x8_T1", F3_T1 = "x1_T1", # F2 = Exchange, F1 = Synchronization, F3 = Exchange
               F1_T2 = "x5_T2", F2_T2 = "x8_T2", F3_T2 = "x1_T2")

# Step 7: Modify the `make_esem_model` function to include both T1 and T2 variables, and anchors
make_esem_model <- function(loadings_dt, anchorsty) {
  # Mark anchors for T1 and T2 variables
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsty)) loadings_dt[latent != l & item == anchorsty[l], is_anchor := 1]
  
  # Create syntax for loadings (apply the anchors where needed)
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables (for both T1 and T2)
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes (T1 and T2)
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Specify covariances between items at T1 and T2
  covariance_syntax <- paste(
    "x1_T1 ~~ x1_T2 \n",
    "x2_T1 ~~ x2_T2 \n",
    "x3_T1 ~~ x3_T2 \n",
    "x4_T1 ~~ x4_T2 \n",
    "x5_T1 ~~ x5_T2 \n",
    "x6_T1 ~~ x6_T2 \n",
    "x7_T1 ~~ x7_T2 \n",
    "x8_T1 ~~ x8_T2 \n",
    "x9_T1 ~~ x9_T2 \n",
    "x10_T1 ~~ x10_T2 \n",
    sep = ""
  )
  
  # Specify correlations between latent factors at T1 and T2
  correlation_syntax <- "F1_T1 ~~ F1_T2 \n
                         F2_T2 ~~ F2_T1 \n
                         F3_T2 ~~ F3_T1 \n"
  
  autoregression_syntax <-  "F1_T2 ~ F1_T1 \n
                             F2_T2 ~ F2_T1 \n
                             F3_T2 ~ F3_T1 \n"
  
  # Combine everything
  paste(measurement_syntax, covariance_syntax, autoregression_syntax, sep = " ")
}

# Step 8: Create the ESEM model syntax
esem_modelty_t2 <- make_esem_model(esem_loadings, anchorsty)

# Print the model syntax for verification
writeLines(esem_modelty_t2)

# Step 9: Fit the ESEM model with both T1 and T2 data 
esem_fit_ty_t1_t2 <- cfa(esem_modelty_t2, 
                         data = esem_ty_t1_t2,  
                         std.lv = TRUE, 
                         estimator = "wlsmv", 
                         estimator.args = list(ESEM = TRUE),
                         control = list(iter.max = 1000, rel.tol = 1e-5), # adjust optimizer for stability
                         ordered = TRUE,
                         parameterization = "theta"
)

# Step 10: Summarize the model fit and results
summary(esem_fit_ty_t1_t2, fit.measures = TRUE, standardized = TRUE)
# F1 = Synchronization, F2 = Co-Construction, F3 = Exchange

# Check correlations between latent factors
lavInspect(esem_fit_ty_t1_t2, "cor.lv")

# Check residual variances of latent variables
parameterEstimates(esem_fit_ty_t1_t2, standardized = TRUE) |>
  dplyr::filter(op == "~~", lhs == rhs, grepl("F", lhs))

# nb from old dataset (still same number of obs though...)
summary(esem_fit_ty, fit.measures = TRUE, standardized = TRUE)


# Related constructs
rel.efa_t1 <- select(utc_data, 
                     tt1_cc2, tt1_cc3, tt1_cc4, tt1_cc6,
                     tt1_cu1.1, tt1_cu1.2, tt1_cu1.3, 
                     tt1_le1.1, tt1_le1.3, tt1_le1.4, tt1_le2)

rel.efa_t1_poly <- polychoric(rel.efa_t1)$rho

rel.efa_t1 <- fa(rel.efa_t1_poly, 
                 nfactors = 3, 
                 rotate = "oblimin", 
                 fm = "wls"
)


print(rel.efa_t1, cut = 0.3, digits = 2)

# Step 2: Perform EFA on T2 Data to obtain loadings
rel.efa_t2 <- select(utc_data, 
                     tt2_cc2, tt2_cc3, tt2_cc4, tt2_cc6,
                     tt2_cu1.1, tt2_cu1.2, tt2_cu1.3, 
                     tt2_le1.1, tt2_le1.3, tt2_le1.4, tt2_le2)


rel.efa_t2_poly <- polychoric(rel.efa_t2)$rho

rel.efa_t2 <- fa(rel.efa_t2_poly, 
                 nfactors = 3, 
                 rotate = "oblimin", 
                 fm = "wls"
)


print(rel.efa_t2, cut = 0.3, digits = 2)

# Step 3: Select both T1 and T2 variables for the ESEM model
esem_rel_t1_t2 <- select(utc_data, 
                         tt1_cc2, tt1_cc3, tt1_cc4, tt1_cc6,
                         tt1_cu1.1, tt1_cu1.2, tt1_cu1.3, 
                         tt1_le1.1, tt1_le1.3, tt1_le1.4, tt1_le2, # T1 Variables
                         tt2_cc2, tt2_cc3, tt2_cc4, tt2_cc6,
                         tt2_cu1.1, tt2_cu1.2, tt2_cu1.3, 
                         tt2_le1.1, tt2_le1.3, tt2_le1.4, tt2_le2 # T2 Variables  
)

# Step 4: Rename the variables for consistency in the model (T1 and T2)
esem_rel_t1_t2 <- rename(esem_rel_t1_t2, 
                         "x1_T1" = tt1_cc2,
                         "x2_T1" = tt1_cc3,
                         "x3_T1" = tt1_cc4,
                         "x4_T1" = tt1_cc6,
                         "x5_T1" = tt1_cu1.1,
                         "x6_T1" = tt1_cu1.2,
                         "x7_T1" = tt1_cu1.3,
                         "x8_T1" = tt1_le1.1,
                         "x9_T1"= tt1_le1.3,
                         "x10_T1"= tt1_le1.4,
                         "x11_T1"= tt1_le2,
                         "x1_T2" = tt2_cc2,
                         "x2_T2" = tt2_cc3,
                         "x3_T2" = tt2_cc4,
                         "x4_T2" = tt2_cc6,
                         "x5_T2" = tt2_cu1.1,
                         "x6_T2" = tt2_cu1.2,
                         "x7_T2" = tt2_cu1.3,
                         "x8_T2" = tt2_le1.1,
                         "x9_T2"= tt2_le1.3,
                         "x10_T2"= tt2_le1.4,
                         "x11_T2"= tt2_le2
)

# Step 5: Prepare the loadings table for both T1 and T2
# Loadings from T1 EFA
esem_loadings_t1 <- data.table(matrix(round(rel.efa_t1$loadings, 2),
                                      nrow = 11, ncol = 3))

# Loadings from T2 EFA
esem_loadings_t2 <- data.table(matrix(round(rel.efa_t2$loadings, 2),
                                      nrow = 11, ncol = 3))

# Name the loadings for clarity
names(esem_loadings_t1) <- c("F1_T1", "F2_T1", "F3_T1")
names(esem_loadings_t2) <- c("F1_T2", "F2_T2", "F3_T2")

# Set the item labels for both T1 and T2
esem_loadings_t1$item <- paste0("x", c(1:11), "_T1")
esem_loadings_t2$item <- paste0("x", c(1:11), "_T2")


# Reshape the data to long format for easier model creation
esem_loadings_t1 <- melt(esem_loadings_t1, "item", variable.name = "latent")
esem_loadings_t2 <- melt(esem_loadings_t2, "item", variable.name = "latent")

# Combine T1 and T2 loadings
esem_loadings <- rbind(esem_loadings_t1, esem_loadings_t2)

# Step 6: Define anchors for T1 and T2 (example: F1_T1 = x3_T1, F1_T2 = x3_T2)
anchorsrel <- c(F1_T1 = "x1_T1", F2_T1 = "x8_T1", F3_T1 = "x6_T1", # F2 = Collab culture, F1 = Contrived coll., F3 = Coll. lead.
                F1_T2 = "x1_T2", F2_T2 = "x8_T2", F3_T2 = "x6_T2")

# Step 7: Modify the `make_esem_model` function to include both T1 and T2 variables, and anchors
make_esem_model <- function(loadings_dt, anchorsrel) {
  # Mark anchors for T1 and T2 variables
  loadings_dt[, is_anchor := 0]
  for (l in names(anchorsrel)) loadings_dt[latent != l & item == anchorsrel[l], is_anchor := 1]
  
  # Create syntax for loadings (apply the anchors where needed)
  loadings_dt[is_anchor == 0, syntax := paste0("start(", value, ")*", item)]
  loadings_dt[is_anchor == 1, syntax := paste0(value, "*", item)]
  
  # Create syntax for latent variables (for both T1 and T2)
  each_syntax <- function (l) {
    paste(l, "=~", paste0(loadings_dt[latent == l, syntax], collapse = " + "), "\n")
  }
  
  # Combine all latent factor syntaxes (T1 and T2)
  measurement_syntax <- paste(sapply(unique(loadings_dt$latent), each_syntax), collapse = " ")
  
  # Specify covariances between items at T1 and T2
  covariance_syntax <- paste(
    "x1_T1 ~~ x1_T2 \n",
    "x2_T1 ~~ x2_T2 \n",
    "x3_T1 ~~ x3_T2 \n",
    "x4_T1 ~~ x4_T2 \n",
    "x5_T1 ~~ x5_T2 \n",
    "x6_T1 ~~ x6_T2 \n",
    "x7_T1 ~~ x7_T2 \n",
    "x8_T1 ~~ x8_T2 \n",
    "x9_T1 ~~ x9_T2 \n",
    "x10_T1 ~~ x10_T2 \n",
    "x11_T1 ~~ x11_T2 \n",
    sep = ""
  )
  
  # Specify correlations between latent factors at T1 and T2
  correlation_syntax <- "F1_T1 ~~ F1_T2 \n
                        F2_T2 ~~ F2_T1 \n
                         F3_T2 ~~ F3_T1 \n"
  
  autoregression_syntax <-  "F1_T2 ~ F1_T1 \n
                             F2_T2 ~ F2_T1 \n
                             F3_T2 ~ F3_T1 \n"
  
  # Combine everything
  paste(measurement_syntax, correlation_syntax, covariance_syntax, autoregression_syntax, sep = " ")
}

# Step 8: Create the ESEM model syntax
esem_modelrel_t2 <- make_esem_model(esem_loadings, anchorsrel)

# Print the model syntax for verification
writeLines(esem_modelrel_t2)

# Step 9: Fit the ESEM model with both T1 and T2 data
esem_fit_rel_t1_t2 <- cfa(esem_modelrel_t2, 
                          data = esem_rel_t1_t2,  
                          std.lv = TRUE, 
                          estimator = "dwls",
                          test= "mv",
                          estimator.args = list(ESEM = TRUE),
                          control = list(iter.max = 1000, rel.tol = 1e-5), # adjust optimizer for stability
                          ordered = TRUE,
                          parameterization = "theta", 
                          missing = "pairwise" # pairwise present, standard missing handling of ordinal vars in lavaan.
)

# Step 10: Summarize the model fit and results
summary(esem_fit_rel_t1_t2, fit.measures = TRUE, standardized = TRUE)
# Note that F1 = Contrived Coll. F2 = collab. lead, F3 = Collab. cult.



