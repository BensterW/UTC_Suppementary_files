# Supplemental material for the article:
# "Unpacking Teacher Collaboration: Validation of Measurement Models Using
# Exploratory Structural Equation Modeling" by Waldejer B., Jensen M. T., 
# Solheim O. J.

# Scripts written by Waldejer B.
# For feedback or questions please send queries to the corresponding author's
# email: benjamin.waldejer@uis.no

# Script 2 ----------------------------------------------------------------
# Information

# This script includes:
# 1. Polychoric matrices and corrplots per Set of constructs
# 2. Parallel Analyses
# 3. Exploratory Graph Analyses
# 4. Exploratory Factor Analyses

# Packages ----------------------------------------------------------------

library(tidyverse)
library(EGAnet)
library(psych)
library(GPArotation)

# 1. Polychoric matrices and corrplots ------------------------------------

# Types of teacher collaboration
types_efa <- select(utc_data, 
                  tt1_fr1, tt1_fr3,
                  tt1_fr5.1:tt1_fr5.4,
                  tt1_de1.1:tt1_de4,
                  tt1_ty1:tt1_ty10)
types_efa_poly <- polychoric(types_efa)$rho

length(types_efa)

# Related constructs
rel_efa <- select(utc_data, 
                  tt1_le1.1:tt1_le3,
                  tt1_an1:tt1_an5,
                  tt1_q1:tt1_q3,
                  tt1_cu1.1:tt1_cu7,
                  tt1_ef1:tt1_ef8,
                  tt1_cc1:tt1_cc6)
rel_efa_poly <- polychoric(rel_efa)$rho

length(rel_efa)

# Check with corrplots
# Correlation plot

types_corplot = cor(use = "complete.obs", types_efa_poly)

corrplot(types_corplot, 
         method = 'number', 
         type = 'lower',
         tl.col='black', 
         tl.cex=.75,
         number.cex = 0.5)

rel_corplot = cor(use = "complete.obs", rel_efa_poly)

corrplot(rel_corplot, 
         method = 'number', 
         type = 'lower',
         tl.col='black', 
         tl.cex=.75,
         number.cex = 0.3)

# 2. Parallell Analyses ---------------------------------------------------

# Double check factor extraction with PA
# Types
pa_types <- fa.parallel(types_efa_poly, 
                       fm = "wls", 
                       fa = "fa", 
                       cor = "poly", 
                       n.obs = 491,
                       main = "Parallel analysis of Collaboration types"
)

print(pa_types)

types_pa <- fa(types_efa_poly, 
              nfactors = 27, # edit number of factors
              rotate = "none", 
              fm = "wls"
)

types_scree <- plot(types_pa$e.values, type = "b", 
                    xlab = "Component Number", ylab = "Eigenvalue",
                    main = "Types EFA Scree Plot")
abline(h = 1, col = "red", lty = 2)
# Suggests 5 factors

# Related constructs
pa_rel <- fa.parallel(rel_efa_poly, 
                       fm = "wls", 
                       fa = "fa", 
                       cor = "poly",
                       n.obs = 491,
                       main = "Parallel analysis of Related constructs"
)

print(pa_rel)

rel_pa <- fa(rel_efa_poly, # Might need raw data with select...
               nfactors = 37, # edit number of factors
               rotate = "none", 
               fm = "wls"
)

rel_scree <- plot(rel_pa$e.values, type = "b", 
                     xlab = "Component Number", ylab = "Eigenvalue",
                     main = "Related Constructs EFA Scree Plot")
abline(h = 1, col = "red", lty = 2)
# suggests 8 factors 

# 3. Exploratory Graph Analyses -------------------------------------------

# Collaboration types
ega_types <- EGA(data = types_efa_poly,
                 model = "glasso",
                 cor = "cor_auto",
                 algorithm = "walktrap",
                 n=491)

print(ega_types)
plot(ega_types)

# Related constructs
ega_rel <- EGA(data = rel_efa_poly,
                 model = "glasso",
                 cor = "cor_auto",
                 algorithm = "walktrap",
                 n=491)

print(ega_rel)
plot(ega_rel)

# 4. Exploratory factor analyses ------------------------------------------
# Note that the EFAs here are largely, but not purely, data driven. For factor 
# retention we also have requirements for stability and theoretical 
# interpretation as described in the article.
# Items are iteratively removed according to criteria, initial and final EFAs
# are reported, not each iteration. To check, follow criteria and remove one
# item at a time from the select functions below. Note that nfactors must be 
# reduced accordingly to reach the solution in the last iteration.

types.eigenvalues <- eigen(cor(select(utc_data, 
                                      tt1_fr1, tt1_fr3,
                                      tt1_fr5.1:tt1_fr5.4,
                                      tt1_de1.1:tt1_de4,
                                      tt1_ty1:tt1_ty10),
                               use = "pairwise.complete.obs"))$values
print(types.eigenvalues)

types_efa1 <- fa(types_efa_poly, 
                 nfactors = 5, 
                 rotate = "oblimin", 
                 fm = "wls",
                 n.obs = 491
)

print(types_efa1, cut = 0.3, digits = 2)

rel.eigenvalues <- eigen(cor(select(utc_data,
                                    tt1_le1.1:tt1_le3,
                                    tt1_an1:tt1_an5,
                                    tt1_q1:tt1_q3,
                                    tt1_cu1.1:tt1_cu7,
                                    tt1_ef1:tt1_ef8,
                                    tt1_cc1:tt1_cc6),
                             use = "pairwise.complete.obs"))$values
print(rel.eigenvalues)

rel_efa1 <- fa(rel_efa_poly, 
               nfactors = 8, 
               rotate = "oblimin", 
               fm = "wls",
               n.obs = 491
)

print(rel_efa1, cut = 0.3, digits = 2)

#################### 4.1 final iteration ########################

# Collaboration types
ty_select <- select(utc_data,
                    tt1_ty1, tt1_ty2,
                    tt1_ty3, 
                    tt1_ty5, tt1_ty8, tt1_ty7, 
                    tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10
)


ty_efa_poly <- polychoric(ty_select)$rho

ety_1 <- fa(ty_efa_poly, 
            nfactors = 3, 
            rotate = "oblimin", 
            fm = "wls"
)

print(ety_1, cut = 0.3, digits = 2) 

# Related Constructs
rel_select <- select(utc_data, 
                     tt1_cu1.1:tt1_cu2,
                     tt1_le1.1,
                     tt1_le1.3,
                     tt1_le1.4,
                     tt1_le2,
                     tt1_cc2:tt1_cc4, tt1_cc6
)


rel_poly <- polychoric(rel_select)$rho

ty_rel_efa <- fa(rel_poly, 
                 nfactors = 3, 
                 rotate = "oblimin", 
                 fm = "wls"
)

print(ty_rel_efa, cut = 0.3, digits = 2) 




