# Supplemental material for the article:
# "Unpacking Teacher Collaboration: Validation of Measurement Models Using
# Exploratory Structural Equation Modeling" by Waldejer B., Jensen M. T., 
# Solheim O. J.

# Scripts written by Waldejer B.
# For feedback or questions please send queries to the corresponding author's
# email: benjamin.waldejer@uis.no

# Script 4 ----------------------------------------------------------------
# Information

# This script includes:
# 1. Cross-Sectional Measurement Invariance Analyses
# 2. Longitudinal Measurement Invariance Analyses
# 3. Intraclass Correlation Coefficients
# 4. Reliability Analyses

# Note that for cross-sectional multigroup invariance models, we use the 
# dataframe with collapsed categories from script 1.

# Packages ----------------------------------------------------------------

library(readxl)
library(tidyverse)
library(semTools)
library(lavaan)
library(psych)
library(ordinal)


# Collapsed category dfs --------------------------------------------------


T1_aug_data <- utc_data |> 
  mutate(across(tt1_ty1:tt1_ty10, ~ case_when( # Exchange for relevant vars
    . %in% c(1, 2) ~ 2,  # Combine categories 1 and 2
    TRUE ~ as.numeric(.)
  )))


T1_aug_data <- T1_aug_data |>  
  mutate(across(tt1_cu1.1:tt1_cu2, ~ case_when(
    . %in% c(1, 2) ~ 2,  # Combine categories 1 and 2
    TRUE ~ as.numeric(.)
  )))

T1_aug_data <- T1_aug_data |>  
  mutate(across(tt1_cc2:tt1_cc6, ~ case_when(
    . %in% c(4, 5) ~ 4,  # Combine categories 4 and 5 (these are scaled opposite of the other vars)
    TRUE ~ as.numeric(.)
  )))

# tt1_le2 empty cat in group 3
T1_aug_data <- T1_aug_data %>%  
  mutate(across(tt1_le2, ~ case_when(
    . %in% c(1, 2) ~ 2,  # Combine categories 1 and 2
    TRUE ~ as.numeric(.)
  )))


# Creating cleaned T1 df to avoid warnings of missingness (removes all T2 vars)
data_t1 <- T1_aug_data[!is.na(T1_aug_data$tt1_ty1), ]

# 1. Cross-Sectional Measurement invariance -------------------------------
# Note that we need to use the dfs with collapsed categories for some of these
# models due to sparse or empty categories. See description in the article
# To avoid warnings of missingness T2 vars are not included in cross-sectional 
# MI analyses.

########## Collaboration types

# Using meas.Eq.syntax()
# Based on the tutorial by Rafael Valdece Sousa Bastos which can be found at: 
# https://towardsdatascience.com/measurement-invariance-definition-and-example-in-r-15b4efcab351/



# Exchange - Baseline (configural)

model1 <- ' eta1_1 =~ tt1_ty1 + 
          tt1_ty2 + 
          tt1_ty3

eta1_2 =~ tt1_ty5 + 
          tt1_ty8 + 
          tt1_ty7

eta1_3 =~ tt1_ty9.1 + 
          tt1_ty9.3 + 
          tt1_ty9.4 +
          tt1_ty10'

baseline <- measEq.syntax(configural.model = model1,
                          data = data_t1, 
                          ordered = TRUE,
                          estimator = "dwls",
                          parameterization = "delta",
                          ID.fac = "std.lv",
                          ID.cat = "Wu.Estabrook.2016",
                          group = "tt1_sex3",
                          group.equal = "configural") # Note that this is pairwise present, standard in lavaan for ordinal vars

model.baseline <- as.character(baseline)


fit.baseline <- cfa(model.baseline,
                    data = data_t1, 
                    group = "tt1_sex3",
                    ordered = TRUE,
                    missing = "pairwise"
)

summary(fit.baseline, fit.measures = TRUE, standardized = TRUE)

# Thresholds Invariance Model

prop4 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered = TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds")
)

model.prop4 <- as.character(prop4)

#Fitting thresholds invariance model in lavaan via cfa function
fit.prop4 <- cfa(model.prop4,
                 data = data_t1, 
                 group = "tt1_sex3",
                 ordered = TRUE
)

# Obtaining results from thresholds invariance model
summary(fit.prop4, fit.measures = TRUE, standardized = TRUE)

anova(fit.prop4,fit.baseline)
lavTestLRT(fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

# Loadings and thresholds ()

prop7 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds", "loadings"))

model.prop7 <- as.character(prop7)

fit.prop7 <- cfa(model.prop7,
                 data = data_t1,
                 group = "tt1_sex3",
                 ordered = TRUE,
)
summary(fit.prop7, fit.measures = TRUE, standardized = TRUE)


anova(fit.prop7, fit.prop4,fit.baseline)
lavTestLRT(fit.prop7, fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_thresholds_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

fit_loadings_fit <- fitMeasures(fit.prop7, c("cfi", "rmsea"))


delta_cfi   <- fit_loadings_fit["cfi"] - fit_thresholds_fit["cfi"]
delta_rmsea <- fit_loadings_fit["rmsea"] - fit_thresholds_fit["rmsea"]

delta_cfi
delta_rmsea

# Testing with residual invariance

prop8 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds", "loadings", "residual"))

model.prop8 <- as.character(prop8)

fit.prop8 <- cfa(model.prop8,
                 data = data_t1, 
                 group = "tt1_sex3",
                 ordered = TRUE,
)
summary(fit.prop8)


# Using Age as grouping variable

# same syntax as above

# Age groups
# Group 1: 18–34 (early-career teachers)
# Group 2: 35–49 (mid-career teachers)
# Group 3: 50–73 (late-career teachers)

data_t1$age_group <- cut( 
  data_t1$tt1_age2 ,
  breaks = c(-Inf, 34, 49, Inf),
  labels = c("early", "mid", "late")
)

table(data_t1$age_group)

baseline <- measEq.syntax(configural.model = model1,
                          data = data_t1, 
                          ordered = TRUE,
                          # estimator = "dwls",
                          parameterization = "delta",
                          ID.fac = "std.lv",
                          ID.cat = "Wu.Estabrook.2016",
                          group = "age_group", 
                          group.equal = "configural")

model.baseline <- as.character(baseline)


fit.baseline <- cfa(model.baseline,
                    data = data_t1, 
                    group = "age_group",
                    ordered = TRUE
)

summary(fit.baseline, fit.measures = TRUE, standardized = TRUE)

# Thresholds Invariance Model

prop4 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered = TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds")
)

model.prop4 <- as.character(prop4)

#Fitting thresholds invariance model in lavaan via cfa function
fit.prop4 <- cfa(model.prop4,
                 data = data_t1, 
                 group = "age_group",
                 ordered = TRUE
)

# Obtaining results from thresholds invariance model
summary(fit.prop4, fit.measures = TRUE, standardized = TRUE)

anova(fit.prop4,fit.baseline)
lavTestLRT(fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea


# Loadings and thresholds ()

prop7 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds", "loadings"))

model.prop7 <- as.character(prop7)

fit.prop7 <- cfa(model.prop7,
                 data = data_t1, 
                 group = "age_group",
                 ordered = TRUE,
)
summary(fit.prop7, fit.measures = TRUE, standardized = TRUE)


anova(fit.prop7, fit.prop4,fit.baseline)
lavTestLRT(fit.prop7, fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_thresholds_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

fit_loadings_fit <- fitMeasures(fit.prop7, c("cfi", "rmsea"))


delta_cfi   <- fit_loadings_fit["cfi"] - fit_thresholds_fit["cfi"]
delta_rmsea <- fit_loadings_fit["rmsea"] - fit_thresholds_fit["rmsea"]

delta_cfi
delta_rmsea

# Testing with equal latent variable variances (strong factorial)

prop8 <- measEq.syntax(configural.model = model1,
                       data = data_t1,
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds", "loadings", "lv.variances"))

model.prop8 <- as.character(prop8)

fit.prop8 <- cfa(model.prop8,
                 data = data_t1, 
                 group = "age_group",
                 ordered = TRUE,
)
summary(fit.prop8)


########## Related Constructs

# Related constructs - Baseline (configural)
# Note that because of convergence issues each construct here has to be modelled
# separately. Remove and ad hastags accordingly then rerun the model.

model1 <- ' 
#eta1_1 =~ tt1_cu1.1 + # For identification
#          tt1_cu1.2 + 
#          tt1_cu1.3 + 
#          tt1_cu2

#eta1_2 =~ tt1_le1.1 + # For identification
#          tt1_le1.3 + 
#          tt1_le1.4 +
#          tt1_le2

eta1_3 =~ tt1_cc2 + # For identification
          tt1_cc3 + 
          tt1_cc4 +
          tt1_cc6'

baseline <- measEq.syntax(configural.model = model1,
                          data = data_t1, 
                          ordered = TRUE,
                          estimator = "dwls",
                          parameterization = "delta",
                          ID.fac = "std.lv",
                          ID.cat = "Wu.Estabrook.2016",
                          group = "tt1_sex3",
                          group.equal = "configural")

model.baseline <- as.character(baseline)


fit.baseline <- cfa(model.baseline,
                    data = data_t1, 
                    group = "tt1_sex3",
                    ordered = TRUE,
                    std.lv=TRUE
)

summary(fit.baseline)

# Thresholds Invariance Model

prop4 <- measEq.syntax(configural.model = model1,
                       data = data_t1, 
                       ordered = TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds")
)

model.prop4 <- as.character(prop4)

#Fitting thresholds invariance model in lavaan via cfa function
fit.prop4 <- cfa(model.prop4,
                 data = data_t1, 
                 group = "tt1_sex3",
                 ordered = TRUE
)

# Obtaining results from thresholds invariance model
summary(fit.prop4)

anova(fit.prop4,fit.baseline)
lavTestLRT(fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

# Loadings and thresholds ()

prop7 <- measEq.syntax(configural.model = model1,
                       data = data_t1,  
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds", "loadings"))

model.prop7 <- as.character(prop7)

fit.prop7 <- cfa(model.prop7,
                 data = data_t1,  
                 group = "tt1_sex3",
                 ordered = TRUE,
)
summary(fit.prop7)


anova(fit.prop7, fit.prop4,fit.baseline)
lavTestLRT(fit.prop7, fit.baseline, fit.prop4, method="satorra.2000")


# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_thresholds_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

fit_loadings_fit <- fitMeasures(fit.prop7, c("cfi", "rmsea"))


delta_cfi   <- fit_loadings_fit["cfi"] - fit_thresholds_fit["cfi"]
delta_rmsea <- fit_loadings_fit["rmsea"] - fit_thresholds_fit["rmsea"]

delta_cfi
delta_rmsea

# Testing with lv variances

prop8 <- measEq.syntax(configural.model = model1,
                       data = data_t1,
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "tt1_sex3",
                       group.equal = c("thresholds", "loadings", "lv.variances"))

model.prop8 <- as.character(prop8)

fit.prop8 <- cfa(model.prop8,
                 data = data_t1,
                 group = "tt1_sex3",
                 ordered = TRUE,
)
summary(fit.prop8)

anova(fit.prop8, fit.prop7, fit.prop4,fit.baseline)
lavTestLRT(fit.prop8, fit.prop7, fit.baseline, fit.prop4, method="satorra.2000")

# Using Age 

# same syntax as above, exchange vars for different constructs

# Age groups
# Group 1: 18–34 (early-career teachers)
# Group 2: 35–49 (mid-career teachers)
# Group 3: 50–73 (late-career teachers)

data_t1$age_group <- cut(
  data_t1$tt1_age2 ,  
  breaks = c(-Inf, 34, 49, Inf),
  labels = c("early", "mid", "late")
)


table(data_t1$age_group)  

baseline <- measEq.syntax(configural.model = model1,
                          data = data_t1, 
                          ordered = TRUE,
                          estimator = "dwls",
                          parameterization = "delta",
                          ID.fac = "std.lv",
                          ID.cat = "Wu.Estabrook.2016",
                          group = "age_group",
                          group.equal = "configural")

model.baseline <- as.character(baseline)


fit.baseline <- cfa(model.baseline,
                    data = data_t1,  
                    group = "age_group",
                    ordered = TRUE
)

summary(fit.baseline)

# Thresholds Invariance Model

prop4 <- measEq.syntax(configural.model = model1,
                       data = data_t1,  
                       ordered = TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds")
)

model.prop4 <- as.character(prop4)

#Fitting thresholds invariance model in lavaan via cfa function
fit.prop4 <- cfa(model.prop4,
                 data = data_t1,  
                 group = "age_group",
                 ordered = TRUE
)

# Obtaining results from thresholds invariance model
summary(fit.prop4)

anova(fit.prop4,fit.baseline)
lavTestLRT(fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

# Loadings and thresholds ()

prop7 <- measEq.syntax(configural.model = model1,
                       data = data_t1,  
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds", "loadings"))

model.prop7 <- as.character(prop7)

fit.prop7 <- cfa(model.prop7,
                 data = data_t1,  
                 group = "age_group",
                 ordered = TRUE,
)
summary(fit.prop7)


anova(fit.prop7, fit.prop4,fit.baseline)
lavTestLRT(fit.prop7, fit.baseline, fit.prop4, method="satorra.2000")

# Configural
fit_configural_fit <- fitMeasures(fit.baseline, c("cfi", "rmsea"))

# Metric
fit_thresholds_fit <- fitMeasures(fit.prop4, c("cfi", "rmsea"))

fit_loadings_fit <- fitMeasures(fit.prop7, c("cfi", "rmsea"))


delta_cfi   <- fit_loadings_fit["cfi"] - fit_thresholds_fit["cfi"]
delta_rmsea <- fit_loadings_fit["rmsea"] - fit_thresholds_fit["rmsea"]

delta_cfi
delta_rmsea

# Testing with equal latent variable variances 

prop8 <- measEq.syntax(configural.model = model1,
                       data = data_t1,  
                       ordered =TRUE,
                       parameterization = "delta",
                       ID.fac = "std.lv",
                       ID.cat = "Wu.Estabrook.2016",
                       group = "age_group",
                       group.equal = c("thresholds", "loadings", "lv.variances"))

model.prop8 <- as.character(prop8)

fit.prop8 <- cfa(model.prop8,
                 data = data_t1, 
                 group = "age_group",
                 ordered = TRUE,
)
summary(fit.prop8)
anova(fit.prop8,fit.prop7, fit.prop4,fit.baseline)

# 2. Longitudinal Measurement Invariance  ---------------------------------

# For the longitudinal invariance models we used syntax from the Change lab by 
# Nilam Ram, Kevin Grim et al, based on the approach by Liu & Millsap:
# https://thechangelab.stanford.edu/tutorials/growth-modeling/modeling-change-latent-vars-ordinal-indicators-lavaan/

############ Collaboration types ###########
# Note that there are three consecutive models corresponding to each dimension
# described in the article. 

# Exchange ----------------------------------------------------------------


configural_invar_exchange <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty1 + 
          tt1_ty2 + 
          tt1_ty3

# Wave 2 factors
eta2_1 =~ 1*tt2_ty1 + 
          tt2_ty2 + 
          tt2_ty3


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty1  ~~ 1*tt1_ty1
tt1_ty2  ~~ 1*tt1_ty2
tt1_ty3  ~~ 1*tt1_ty3

tt2_ty1  ~~ 1*tt2_ty1
tt2_ty2  ~~ 1*tt2_ty2
tt2_ty3  ~~ 1*tt2_ty3


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty1   | t1 + t2 + t3 + t4
tt1_ty2   | t1 + t2 + t3 + t4
tt1_ty3   | t1 + t2 + t3 + t4

# Wave 2
tt2_ty1   | t1 + t2 + t3 
tt2_ty2   | t1 + t2 + t3 + t4
tt2_ty3   | t1 + t2 + t3 + t4

'
fit_configural_exchange <- cfa(configural_invar_exchange, 
                               #estimator="dwls", 
                               data = utc_data, 
                               parameterization="theta", 
                               missing="pairwise",
                               ordered=TRUE, 
                               std.lv=TRUE,
                               # se = "bootstrap",         
                               # bootstrap = 500
)

summary(fit_configural_exchange, fit.measures = TRUE)

lavInspect(fit_configural_exchange, "cor.lv")

########### Weak invariance (factorial invariance) ############

weak_invar_exchange <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty1 + #for identification
          lambda_i*tt1_ty2 + 
          lambda_e*tt1_ty3

# Wave 2 factors
eta2_1 =~ 1*tt2_ty1 + #for identification
          lambda_i*tt2_ty2 + 
          lambda_e*tt2_ty3


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty1  ~~ 1*tt1_ty1
tt1_ty2  ~~ 1*tt1_ty2
tt1_ty3  ~~ 1*tt1_ty3

tt2_ty1  ~~ 1*tt2_ty1
tt2_ty2  ~~ 1*tt2_ty2
tt2_ty3  ~~ 1*tt2_ty3


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty1   | t1 + t2 + t3 + t4
tt1_ty2   | t1 + t2 + t3 + t4
tt1_ty3   | t1 + t2 + t3 + t4

# Wave 2
tt2_ty1   | t1 + t2 + t3
tt2_ty2   | t1 + t2 + t3 + t4
tt2_ty3   | t1 + t2 + t3 + t4

'
fit_weak_exchange <- cfa(weak_invar_exchange, 
                         #estimator="dwls", 
                         data = utc_data, 
                         parameterization="theta", 
                         missing="pairwise",
                         ordered=TRUE, 
                         std.lv=TRUE)

summary(fit_weak_exchange, fit.measures = TRUE)

lavInspect(fit_weak_exchange, "cor.lv")

anova(fit_configural_exchange, fit_weak_exchange)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_exchange, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_exchange, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

################## Strong invariance ####################

strong_invar_exchange <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty1 + #for identification
          lambda_i*tt1_ty2 + 
          lambda_e*tt1_ty3

# Wave 2 factors
eta2_1 =~ 1*tt2_ty1 + #for identification
          lambda_i*tt2_ty2 + 
          lambda_e*tt2_ty3


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 1 #NB.free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty1  ~~ 1*tt1_ty1
tt1_ty2  ~~ 1*tt1_ty2
tt1_ty3  ~~ 1*tt1_ty3

tt2_ty1  ~~ 1*tt2_ty1
tt2_ty2  ~~ 1*tt2_ty2
tt2_ty3  ~~ 1*tt2_ty3

########################################
#      unique covariances
########################################


########################################
#      observed variable intercepts (now with equality constraints)
########################################

# Wave 1
tt1_ty1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4 # free this thresholds for partial scalar test...
tt1_ty2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_ty3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4

# Wave 2
tt2_ty1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 # free this thresholds for partial scalar test...
tt2_ty2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_ty3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4

'
fit_strong_exchange <- cfa(strong_invar_exchange, 
                           # estimator="dwls", 
                           data = utc_data, 
                           parameterization="theta", 
                           missing="pairwise",
                           ordered=TRUE, 
                           std.lv=TRUE)

summary(fit_strong_exchange, fit.measures = TRUE)

lavInspect(fit_strong_exchange, "cor.lv")

anova(fit_configural_exchange, fit_weak_exchange, fit_strong_exchange)

# Configural
fit_configural_fit <- fitMeasures(fit_configural_exchange, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_exchange, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_exchange, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

delta_cfi
delta_rmsea

mod_indices <- modificationIndices(fit_strong_exchange, sort. = TRUE)
head(mod_indices, 10)

# Synchronization T1-T2 ---------------------------------------------------

configural_invar_synch <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty5 + 
          tt1_ty7 + 
          tt1_ty8

# Wave 2 factors
eta2_1 =~ 1*tt2_ty5 + 
          tt2_ty7 + 
          tt2_ty8


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty5  ~~ 1*tt1_ty5
tt1_ty7  ~~ 1*tt1_ty7
tt1_ty8  ~~ 1*tt1_ty8

tt2_ty5  ~~ 1*tt2_ty5
tt2_ty7  ~~ 1*tt2_ty7
tt2_ty8  ~~ 1*tt2_ty8


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty5   | t1 + t2 + t3 + t4
tt1_ty7   | t1 + t2 + t3 + t4
tt1_ty8   | t1 + t2 + t3 + t4

# Wave 2
tt2_ty5   | t1 + t2 + t3 + t4
tt2_ty7   | t1 + t2 + t3 + t4
tt2_ty8   | t1 + t2 + t3 + t4

'

fit_configural_synch <- cfa(configural_invar_synch, 
                            # estimator="dwls", 
                            data = utc_data, 
                            parameterization="theta", 
                            missing="pairwise",
                            ordered=TRUE, 
                            std.lv=TRUE)

summary(fit_configural_synch, fit.measures = TRUE)

lavInspect(fit_configural_synch, "cor.lv")

########### Weak invariance (factorial invariance) ############
weak_invar_synch <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty5 + #for identification
          lambda_i*tt1_ty7 + 
          lambda_e*tt1_ty8

# Wave 2 factors
eta2_1 =~ 1*tt2_ty5 + #for identification
          lambda_i*tt2_ty7 + 
          lambda_e*tt2_ty8


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty5  ~~ 1*tt1_ty5
tt1_ty7  ~~ 1*tt1_ty7
tt1_ty8  ~~ 1*tt1_ty8

tt2_ty5  ~~ 1*tt2_ty5
tt2_ty7  ~~ 1*tt2_ty7
tt2_ty8  ~~ 1*tt2_ty8


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty5   | t1 + t2 + t3 + t4
tt1_ty7   | t1 + t2 + t3 + t4
tt1_ty8   | t1 + t2 + t3 + t4

# Wave 2
tt2_ty5   | t1 + t2 + t3 + t4
tt2_ty7   | t1 + t2 + t3 + t4
tt2_ty8   | t1 + t2 + t3 + t4

'

fit_weak_synch <- cfa(weak_invar_synch, 
                      #estimator="dwls", 
                      data = utc_data, 
                      parameterization="theta", 
                      missing="pairwise",
                      ordered=TRUE, 
                      std.lv=TRUE)

summary(fit_weak_synch, fit.measures = TRUE)

lavInspect(fit_weak_synch, "cor.lv")

anova(fit_configural_synch, fit_weak_synch)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_synch, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_synch, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

################## Strong invariance ####################

strong_invar_synch <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty5 + #for identification
          lambda_i*tt1_ty7 + 
          lambda_e*tt1_ty8

# Wave 2 factors
eta2_1 =~ 1*tt2_ty5 + #for identification
          lambda_i*tt2_ty7 + 
          lambda_e*tt2_ty8


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 #for scaling

eta2_1 ~ 1 #free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty5  ~~ 1*tt1_ty5
tt1_ty7  ~~ 1*tt1_ty7
tt1_ty8  ~~ 1*tt1_ty8

tt2_ty5  ~~ 1*tt2_ty5
tt2_ty7  ~~ 1*tt2_ty7
tt2_ty8  ~~ 1*tt2_ty8


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty5   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_ty7   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_ty8   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4

# Wave 2
tt2_ty5   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_ty7   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_ty8   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4

'

fit_strong_synch <- cfa(strong_invar_synch, 
                        # estimator="dwls", 
                        data = utc_data, 
                        parameterization="theta", 
                        missing="pairwise",
                        ordered=TRUE, 
                        std.lv=TRUE)

summary(fit_strong_synch, fit.measures = TRUE)

lavInspect(fit_strong_synch, "cor.lv")

anova(fit_configural_synch, fit_weak_synch, fit_strong_synch)

# Configural
fit_configural_fit <- fitMeasures(fit_configural_synch, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_synch, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_synch, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

delta_cfi
delta_rmsea

# Co-Construction T1-T2 ---------------------------------------------------

configural_invar_co_cons <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty9.1 + 
          tt1_ty9.3 + 
          tt1_ty9.4 +
          tt1_ty10

# Wave 2 factors
eta2_1 =~ 1*tt2_ty9.1 + 
          tt2_ty9.3 + 
          tt2_ty9.4 + 
          tt2_ty10


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty9.1  ~~ 1*tt1_ty9.1
tt1_ty9.3  ~~ 1*tt1_ty9.3
tt1_ty9.4  ~~ 1*tt1_ty9.4
tt1_ty10   ~~ 1*tt1_ty10

tt2_ty9.1  ~~ 1*tt2_ty9.1
tt2_ty9.3  ~~ 1*tt2_ty9.3
tt2_ty9.4  ~~ 1*tt2_ty9.4
tt2_ty10   ~~ 1*tt2_ty10



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty9.1   | t1 + t2 + t3 + t4
tt1_ty9.3   | t1 + t2 + t3 + t4
tt1_ty9.4   | t1 + t2 + t3 + t4
tt1_ty10    | t1 + t2 + t3 + t4

# Wave 2
tt2_ty9.1   | t1 + t2 + t3 + t4
tt2_ty9.3   | t1 + t2 + t3 + t4
tt2_ty9.4   | t1 + t2 + t3 + t4
tt2_ty10    | t1 + t2 + t3 + t4

'

fit_configural_co_cons <- cfa(configural_invar_co_cons, 
                              # estimator="dwls", 
                              data = utc_data,
                              parameterization="theta",
                              missing="pairwise",
                              ordered=TRUE, 
                              std.lv=TRUE)

summary(fit_configural_co_cons, fit.measures = TRUE)

lavInspect(fit_configural_co_cons, "cor.lv")

########### Weak invariance (factorial invariance) ############

weak_invar_co_cons <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty9.1 + #for identification
          lambda_i*tt1_ty9.3 + 
          lambda_e*tt1_ty9.4 +
          lambda_f*tt1_ty10

# Wave 2 factors
eta2_1 =~ 1*tt2_ty9.1 + #for identification
          lambda_i*tt2_ty9.3 + 
          lambda_e*tt2_ty9.4 + 
          lambda_f*tt2_ty10


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty9.1  ~~ 1*tt1_ty9.1
tt1_ty9.3  ~~ 1*tt1_ty9.3
tt1_ty9.4  ~~ 1*tt1_ty9.4
tt1_ty10   ~~ 1*tt1_ty10

tt2_ty9.1  ~~ 1*tt2_ty9.1
tt2_ty9.3  ~~ 1*tt2_ty9.3
tt2_ty9.4  ~~ 1*tt2_ty9.4
tt2_ty10   ~~ 1*tt2_ty10



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty9.1   | t1 + t2 + t3 + t4
tt1_ty9.3   | t1 + t2 + t3 + t4
tt1_ty9.4   | t1 + t2 + t3 + t4
tt1_ty10    | t1 + t2 + t3 + t4

# Wave 2
tt2_ty9.1   | t1 + t2 + t3 + t4
tt2_ty9.3   | t1 + t2 + t3 + t4
tt2_ty9.4   | t1 + t2 + t3 + t4
tt2_ty10    | t1 + t2 + t3 + t4

'

fit_weak_co_cons <- cfa(weak_invar_co_cons, 
                        # estimator="dwls", 
                        data = utc_data, 
                        parameterization="theta", 
                        missing="pairwise",
                        ordered=TRUE, 
                        std.lv=TRUE)

summary(fit_weak_co_cons, fit.measures = TRUE)

lavInspect(fit_weak_co_cons, "cor.lv")

anova(fit_configural_co_cons, fit_weak_co_cons)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cons, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cons, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea


################## Strong invariance ####################

strong_invar_co_cons <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_ty9.1 + #for identification
          lambda_i*tt1_ty9.3 + 
          lambda_e*tt1_ty9.4 +
          lambda_f*tt1_ty10

# Wave 2 factors
eta2_1 =~ 1*tt2_ty9.1 + #for identification
          lambda_i*tt2_ty9.3 + 
          lambda_e*tt2_ty9.4 + 
          lambda_f*tt2_ty10


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 # for scaling

eta2_1 ~ 1 # nb. free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_ty9.1  ~~ 1*tt1_ty9.1
tt1_ty9.3  ~~ 1*tt1_ty9.3
tt1_ty9.4  ~~ 1*tt1_ty9.4
tt1_ty10   ~~ 1*tt1_ty10

tt2_ty9.1  ~~ 1*tt2_ty9.1
tt2_ty9.3  ~~ 1*tt2_ty9.3
tt2_ty9.4  ~~ 1*tt2_ty9.4
tt2_ty10   ~~ 1*tt2_ty10



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_ty9.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_ty9.3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_ty9.4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt1_ty10    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4


# Wave 2
tt2_ty9.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_ty9.3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_ty9.4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt2_ty10    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4

'

fit_strong_co_cons <- cfa(strong_invar_co_cons, 
                          # estimator="dwls", 
                          data = utc_data, 
                          parameterization="theta", 
                          missing="pairwise",
                          ordered=TRUE, 
                          std.lv=TRUE)

summary(fit_strong_co_cons, fit.measures = TRUE)

lavInspect(fit_strong_co_cons, "cor.lv")

anova(fit_configural_co_cons, fit_weak_co_cons, fit_strong_co_cons)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cons, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cons, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_co_cons, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

delta_cfi
delta_rmsea

######### Related constructs
# Related constructs - CU -------------------------------------------------


configural_invar_co_cul <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cu1.1 + 
          tt1_cu1.2 + 
          tt1_cu1.3 +
          tt1_cu2

# Wave 2 factors
eta2_1 =~ 1*tt2_cu1.1 + 
          tt2_cu1.2 + 
          tt2_cu1.3 + 
          tt2_cu2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2   ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2   ~~ 1*tt2_cu2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cu1.1   | t1 + t2 + t3 + t4
tt1_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3 + t4
tt1_cu2    | t1 + t2 + t3 + t4

# Wave 2
tt2_cu1.1   | t1 + t2 + t3 + t4
tt2_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3
tt1_cu2    | t1 + t2 + t3

'

fit_configural_co_cul <- cfa(configural_invar_co_cul, 
                             estimator="dwls", 
                             test = "mv", # remove if issues
                             data = utc_data,
                             parameterization="theta", 
                             missing="pairwise",
                             ordered=TRUE, 
                             std.lv=TRUE)

summary(fit_configural_co_cul, fit.measures = TRUE)

lavInspect(fit_configural_co_cul, "cor.lv")



########### Weak invariance (factorial invariance) ############

weak_invar_co_cul <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cu1.1 + #for identification
          lambda_i*tt1_cu1.2 + 
          lambda_e*tt1_cu1.3 +
          lambda_f*tt1_cu2

# Wave 2 factors
eta2_1 =~ 1*tt2_cu1.1 + #for identification
          lambda_i*tt2_cu1.2 + 
          lambda_e*tt2_cu1.3 + 
          lambda_f*tt2_cu2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2    ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2    ~~ 1*tt2_cu2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cu1.1   | t1 + t2 + t3 + t4
tt1_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3 + t4
tt1_cu2     | t1 + t2 + t3 + t4

# Wave 2
tt2_cu1.1   | t1 + t2 + t3 + t4
tt2_cu1.2   | t1 + t2 + t3 + t4
tt2_cu1.3   | t1 + t2 + t3
tt2_cu2     | t1 + t2 + t3

'

fit_weak_co_cul <- cfa(weak_invar_co_cul, 
                       estimator="dwls", 
                       test = "mv", # remove if convergence issues
                       data = utc_data, 
                       parameterization="theta", 
                       missing="pairwise",
                       ordered=TRUE, 
                       std.lv=TRUE)

summary(fit_weak_co_cul, fit.measures = TRUE)

lavInspect(fit_weak_co_cul, "cor.lv")

anova(fit_configural_co_cul, fit_weak_co_cul)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cul, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cul, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

################## Strong invariance ####################

strong_invar_co_cul <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cu1.1 + #for identification
          lambda_i*tt1_cu1.2 + 
          lambda_e*tt1_cu1.3 +
          lambda_f*tt1_cu2

# Wave 2 factors
eta2_1 =~ 1*tt2_cu1.1 + #for identification
          lambda_i*tt2_cu1.2 + 
          lambda_e*tt2_cu1.3 + 
          lambda_f*tt2_cu2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 # for scaling

eta2_1 ~ 1 # nb. free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2   ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2   ~~ 1*tt2_cu2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cu1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_cu1.2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_cu1.3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt1_cu2    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4


# Wave 2
tt2_cu1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_cu1.2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_cu1.3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3
tt2_cu2    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3

'

fit_strong_co_cul <- cfa(strong_invar_co_cul, 
                         estimator="dwls", 
                         test = "mv",
                         data = utc_data, 
                         parameterization="theta", 
                         missing="pairwise",
                         ordered=TRUE, 
                         std.lv=TRUE)

summary(fit_strong_co_cul, fit.measures = TRUE)

lavInspect(fit_strong_co_cul, "cor.lv")

anova(fit_configural_co_cul, fit_weak_co_cul, fit_strong_co_cul)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cul, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cul, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_co_cul, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

delta_cfi
delta_rmsea


# Related constructs - Le -------------------------------------------------


configural_invar_co_le <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_le1.1 + 
          tt1_le1.3 + 
          tt1_le1.4 +
          tt1_le2

# Wave 2 factors
eta2_1 =~ 1*tt2_le1.1 + 
          tt2_le1.3 + 
          tt2_le1.4 + 
          tt2_le2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2   ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2   ~~ 1*tt2_le2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_le1.1   | t1 + t2 + t3 + t4
tt1_le1.3   | t1 + t2 + t3 + t4
tt1_le1.4   | t1 + t2 + t3 + t4
tt1_le2    | t1 + t2 + t3 + t4

# Wave 2
tt2_le1.1   | t1 + t2 + t3 + t4
tt2_le1.3   | t1 + t2 + t3 + t4
tt2_le1.4   | t1 + t2 + t3 + t4
tt2_le2    | t1 + t2 + t3 + t4

'

fit_configural_co_le <- cfa(configural_invar_co_le, 
                            estimator="dwls", 
                            test = "mv",
                            data = utc_data,
                            parameterization="theta", 
                            missing="pairwise",
                            ordered=TRUE, 
                            std.lv=TRUE)


summary(fit_configural_co_le, fit.measures = TRUE)

lavInspect(fit_configural_co_le, "cor.lv")



########### Weak invariance (factorial invariance) ############

weak_invar_co_le <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_le1.1 + #for identification
          lambda_i*tt1_le1.3 + 
          lambda_e*tt1_le1.4 +
          lambda_f*tt1_le2

# Wave 2 factors
eta2_1 =~ 1*tt2_le1.1 + #for identification
          lambda_i*tt2_le1.3 + 
          lambda_e*tt2_le1.4 + 
          lambda_f*tt2_le2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2    ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2    ~~ 1*tt2_le2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_le1.1   | t1 + t2 + t3 + t4
tt1_le1.3   | t1 + t2 + t3 + t4
tt1_le1.4   | t1 + t2 + t3 + t4
tt1_le2     | t1 + t2 + t3 + t4

# Wave 2
tt2_le1.1   | t1 + t2 + t3 + t4
tt2_le1.3   | t1 + t2 + t3 + t4
tt2_le1.4   | t1 + t2 + t3
tt2_le2     | t1 + t2 + t3

'

fit_weak_co_le <- cfa(weak_invar_co_le, 
                      estimator="dwls", 
                      test = "mv",
                      data = utc_data, 
                      parameterization="theta", 
                      missing="pairwise",
                      ordered=TRUE, 
                      std.lv=TRUE)

summary(fit_weak_co_le, fit.measures = TRUE)

lavInspect(fit_weak_co_le, "cor.lv")

anova(fit_configural_co_le, fit_weak_co_le)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_le, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_le, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

delta_cfi
delta_rmsea

################## Strong invariance ####################

strong_invar_co_le <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_le1.1 + #for identification
          lambda_i*tt1_le1.3 + 
          lambda_e*tt1_le1.4 +
          lambda_f*tt1_le2

# Wave 2 factors
eta2_1 =~ 1*tt2_le1.1 + #for identification
          lambda_i*tt2_le1.3 + 
          lambda_e*tt2_le1.4 + 
          lambda_f*tt2_le2


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 # for scaling

eta2_1 ~ 1 # nb. free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2   ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2   ~~ 1*tt2_le2



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_le1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_le1.3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_le1.4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt1_le2    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4


# Wave 2
tt2_le1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_le1.3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_le1.4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt2_le2    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4

'

fit_strong_co_le <- cfa(strong_invar_co_le, 
                        estimator="dwls", 
                        test = "mv",
                        data = utc_data, 
                        parameterization="theta", 
                        missing="pairwise",
                        ordered=TRUE, 
                        std.lv=TRUE)

summary(fit_strong_co_le, fit.measures = TRUE)

lavInspect(fit_strong_co_le, "cor.lv")

anova(fit_configural_co_le, fit_weak_co_le, fit_strong_co_le)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_le, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_le, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_co_le, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

delta_cfi
delta_rmsea


# Related constructs - CC -------------------------------------------------


configural_invar_co_cc <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + 
          tt1_cc3 + 
          tt1_cc4 +
          tt1_cc6

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + 
          tt2_cc3 + 
          tt2_cc4 + 
          tt2_cc6


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6  ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6  ~~ 1*tt2_cc6



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cc2   | t1 + t2 + t3 + t4
tt1_cc3   | t1 + t2 + t3 + t4
tt1_cc4   | t1 + t2 + t3 + t4
tt1_cc6   | t1 + t2 + t3 + t4

# Wave 2
tt2_cc2   | t1 + t2 + t3 + t4
tt2_cc3   | t1 + t2 + t3 + t4
tt2_cc4   | t1 + t2 + t3 + t4
tt2_cc6   | t1 + t2 + t3 + t4

'

fit_configural_co_cc <- cfa(configural_invar_co_cc, 
                            estimator="dwls", 
                            test = "mv", 
                            data = utc_data, 
                            parameterization="theta", 
                            missing="pairwise",
                            ordered=TRUE, std.lv=TRUE)

summary(fit_configural_co_cc, fit.measures = TRUE)

lavInspect(fit_configural_co_cc, "cor.lv")


########### Weak invariance (factorial invariance) ############

weak_invar_co_cc <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + #for identification
          lambda_i*tt1_cc3 + 
          lambda_e*tt1_cc4 +
          lambda_f*tt1_cc6

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + #for identification
          lambda_i*tt2_cc3 + 
          lambda_e*tt2_cc4 + 
          lambda_f*tt2_cc6


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1

eta2_1 ~ 0*1



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6    ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6   ~~ 1*tt2_cc6



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cc2   | t1 + t2 + t3 + t4
tt1_cc3   | t1 + t2 + t3 + t4
tt1_cc4   | t1 + t2 + t3 + t4
tt1_cc6   | t1 + t2 + t3 + t4

# Wave 2
tt2_cc2   | t1 + t2 + t3 + t4
tt2_cc3   | t1 + t2 + t3 + t4
tt2_cc4   | t1 + t2 + t3 + t4
tt2_cc6   | t1 + t2 + t3 + t4

'

fit_weak_co_cc <- cfa(weak_invar_co_cc, 
                      estimator="dwls", 
                      test= "mv",
                      data = utc_data, 
                      parameterization="theta", 
                      missing="pairwise",
                      ordered=TRUE, std.lv=TRUE)

summary(fit_weak_co_cc, fit.measures = TRUE)

lavInspect(fit_weak_co_cc, "cor.lv")

anova(fit_configural_co_cc, fit_weak_co_cc)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cc, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cc, c("cfi", "rmsea"))

delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

# Extract robust (scaled) fit indices
fit_metric_fit <- fitMeasures(fit_weak_co_cc, c("cfi.scaled", "rmsea.scaled"))
fit_configural_fit <- fitMeasures(fit_configural_co_cc, c("cfi.scaled", "rmsea.scaled"))

# Compute differences 
delta_cfi   <- fit_metric_fit["cfi.scaled"] - fit_configural_fit["cfi.scaled"]
delta_rmsea <- fit_metric_fit["rmsea.scaled"] - fit_configural_fit["rmsea.scaled"]


delta_cfi 
delta_rmsea

################## Strong invariance ####################

strong_invar_co_cc <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + #for identification
          lambda_i*tt1_cc3 + 
          lambda_e*tt1_cc4 +
          lambda_f*tt1_cc6

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + #for identification
          lambda_i*tt2_cc3 + 
          lambda_e*tt2_cc4 + 
          lambda_f*tt2_cc6


########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1

eta2_1 ~~ eta2_1



########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta2_1


########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 # for scaling

eta2_1 ~ 1 # nb. free



########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6    ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6   ~~ 1*tt2_cc6



########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cc2   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_cc3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_cc4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt1_cc6    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4


# Wave 2
tt2_cc2   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_cc3   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_cc4   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt2_cc6    | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4

'

fit_strong_co_cc <- cfa(strong_invar_co_cc, 
                        estimator="dwls", 
                        test = "mv", 
                        data = utc_data, 
                        parameterization="theta", 
                        missing="pairwise",
                        ordered=TRUE, std.lv=TRUE)

summary(fit_strong_co_cc, fit.measures = TRUE)

lavInspect(fit_strong_co_cc, "cor.lv")

anova(fit_configural_co_cc, fit_weak_co_cc, fit_strong_co_cc)
# Configural
fit_configural_fit <- fitMeasures(fit_configural_co_cc, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_co_cc, c("cfi", "rmsea"))

# Strong (scalar)
fit_strong_fit <- fitMeasures(fit_strong_co_cc, c("cfi", "rmsea"))


delta_cfi   <- fit_strong_fit["cfi"] - fit_metric_fit["cfi"]
delta_rmsea <- fit_strong_fit["rmsea"] - fit_metric_fit["rmsea"]

# Extract robust (scaled) fit indices
fit_metric_fit <- fitMeasures(fit_weak_co_cc, c("cfi.scaled", "rmsea.scaled"))
fit_strong_fit <- fitMeasures(fit_strong_co_cc, c("cfi.scaled", "rmsea.scaled"))

# Compute differences 
delta_cfi   <- fit_strong_fit["cfi.scaled"] - fit_metric_fit["cfi.scaled"]
delta_rmsea <- fit_strong_fit["rmsea.scaled"] - fit_metric_fit["rmsea.scaled"]



delta_cfi 
delta_rmsea


# Testing all related constructs in one invariance mod --------------------



configural_invar_rel_c <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + 
          tt1_cc3 + 
          tt1_cc4 +
          tt1_cc6

# Wave 1 factors
eta1_2 =~ 1*tt1_cu1.1 + 
          tt1_cu1.2 + 
          tt1_cu1.3 +
          tt1_cu2
          
eta1_3 =~ 1*tt1_le1.1 + 
          tt1_le1.3 + 
          tt1_le1.4 +
          tt1_le2          

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + 
          tt2_cc3 + 
          tt2_cc4 + 
          tt2_cc6
          
# Wave 2 factors
eta2_2 =~ 1*tt2_cu1.1 + 
          tt2_cu1.2 + 
          tt2_cu1.3 + 
          tt2_cu2
          
eta2_3 =~ 1*tt2_le1.1 + 
          tt2_le1.3 + 
          tt2_le1.4 + 
          tt2_le2          

########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1
eta1_2 ~~ eta1_2
eta1_3 ~~ eta1_3

eta2_1 ~~ eta2_1
eta2_2 ~~ eta2_2
eta2_3 ~~ eta2_3

########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta1_2
eta1_2 ~~ eta1_3
eta1_1 ~~ eta1_3

eta2_1 ~~ eta2_2
eta2_2 ~~ eta2_3
eta2_1 ~~ eta2_3


# Cross-time covariances (same factor across times)
eta1_1 ~~ eta2_1
eta1_2 ~~ eta2_2
eta1_3 ~~ eta2_3

########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1
eta1_2 ~ 0*1
eta1_3 ~ 0*1

eta2_1 ~ 0*1
eta2_2 ~ 0*1
eta2_3 ~ 0*1

########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6  ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6  ~~ 1*tt2_cc6

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2   ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2   ~~ 1*tt2_cu2

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2   ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2   ~~ 1*tt2_le2


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cc2   | t1 + t2 + t3 + t4
tt1_cc3   | t1 + t2 + t3 + t4
tt1_cc4   | t1 + t2 + t3 + t4
tt1_cc6   | t1 + t2 + t3 + t4

tt1_cu1.1   | t1 + t2 + t3 + t4
tt1_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3 + t4
tt1_cu2    | t1 + t2 + t3 + t4

tt1_le1.1   | t1 + t2 + t3 + t4
tt1_le1.3   | t1 + t2 + t3 + t4
tt1_le1.4   | t1 + t2 + t3 + t4
tt1_le2    | t1 + t2 + t3 + t4

# Wave 2
tt2_cc2   | t1 + t2 + t3 + t4
tt2_cc3   | t1 + t2 + t3 + t4
tt2_cc4   | t1 + t2 + t3 + t4
tt2_cc6   | t1 + t2 + t3 + t4

tt2_cu1.1   | t1 + t2 + t3 + t4
tt2_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3
tt1_cu2    | t1 + t2 + t3

tt2_le1.1   | t1 + t2 + t3 + t4
tt2_le1.3   | t1 + t2 + t3 + t4
tt2_le1.4   | t1 + t2 + t3 + t4
tt2_le2    | t1 + t2 + t3 + t4


'

fit_configural_rel_c <- cfa(configural_invar_rel_c, 
                            estimator="dwls", 
                            test = "mv", 
                            data = utc_data, 
                            parameterization="theta", 
                            missing="pairwise",
                            ordered=TRUE)

summary(fit_configural_rel_c, fit.measures = TRUE)

lavInspect(fit_configural_rel_c, "cor.lv")



# weak invariance ---------------------------------------------------------

weak_invar_rel_c <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + 
          lambda_i*tt1_cc3 + 
          lambda_e*tt1_cc4 +
          lambda_f*tt1_cc6

# Wave 1 factors
eta1_2 =~ 1*tt1_cu1.1 + 
          lambda_g*tt1_cu1.2 + 
          lambda_h*tt1_cu1.3 +
          lambda_j*tt1_cu2
          
eta1_3 =~ 1*tt1_le1.1 + 
          lambda_k*tt1_le1.3 + 
          lambda_l*tt1_le1.4 +
          lambda_m*tt1_le2          

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + 
          lambda_i*tt2_cc3 + 
          lambda_e*tt2_cc4 + 
          lambda_f*tt2_cc6
          
# Wave 2 factors
eta2_2 =~ 1*tt2_cu1.1 + 
          lambda_g*tt2_cu1.2 + 
          lambda_h*tt2_cu1.3 + 
          lambda_j*tt2_cu2
          
eta2_3 =~ 1*tt2_le1.1 + 
          lambda_k*tt2_le1.3 + 
          lambda_l*tt2_le1.4 + 
          lambda_m*tt2_le2          

########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1
eta1_2 ~~ eta1_2
eta1_3 ~~ eta1_3

eta2_1 ~~ eta2_1
eta2_2 ~~ eta2_2
eta2_3 ~~ eta2_3

########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta1_2
eta1_2 ~~ eta1_3
eta1_1 ~~ eta1_3

eta2_1 ~~ eta2_2
eta2_2 ~~ eta2_3
eta2_1 ~~ eta2_3


# Cross-time covariances (same factor across times)
eta1_1 ~~ eta2_1
eta1_2 ~~ eta2_2
eta1_3 ~~ eta2_3

########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1
eta1_2 ~ 0*1
eta1_3 ~ 0*1

eta2_1 ~ 0*1
eta2_2 ~ 0*1
eta2_3 ~ 0*1

########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6  ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6  ~~ 1*tt2_cc6

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2   ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2   ~~ 1*tt2_cu2

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2   ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2   ~~ 1*tt2_le2


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cc2   | t1 + t2 + t3 + t4
tt1_cc3   | t1 + t2 + t3 + t4
tt1_cc4   | t1 + t2 + t3 + t4
tt1_cc6   | t1 + t2 + t3 + t4

tt1_cu1.1   | t1 + t2 + t3 + t4
tt1_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3 + t4
tt1_cu2    | t1 + t2 + t3 + t4

tt1_le1.1   | t1 + t2 + t3 + t4
tt1_le1.3   | t1 + t2 + t3 + t4
tt1_le1.4   | t1 + t2 + t3 + t4
tt1_le2    | t1 + t2 + t3 + t4

# Wave 2
tt2_cc2   | t1 + t2 + t3 + t4
tt2_cc3   | t1 + t2 + t3 + t4
tt2_cc4   | t1 + t2 + t3 + t4
tt2_cc6   | t1 + t2 + t3 + t4

tt2_cu1.1   | t1 + t2 + t3 + t4
tt2_cu1.2   | t1 + t2 + t3 + t4
tt1_cu1.3   | t1 + t2 + t3
tt1_cu2    | t1 + t2 + t3

tt2_le1.1   | t1 + t2 + t3 + t4
tt2_le1.3   | t1 + t2 + t3 + t4
tt2_le1.4   | t1 + t2 + t3 + t4
tt2_le2    | t1 + t2 + t3 + t4

'
fit_weak_rel_c <- cfa(weak_invar_rel_c, 
                      estimator="dwls", 
                      test= "mv", 
                      data = utc_data, 
                      parameterization="theta", 
                      missing="pairwise",
                      ordered=TRUE)

summary(fit_weak_rel_c, fit.measures = TRUE)

lavInspect(fit_weak_rel_c, "cor.lv")

anova(fit_configural_rel_c, fit_weak_rel_c)

# Configural
fit_configural_fit <- fitMeasures(fit_configural_rel_c, c("cfi", "rmsea"))

# Metric
fit_metric_fit <- fitMeasures(fit_weak_rel_c, c("cfi", "rmsea"))


delta_cfi   <- fit_metric_fit["cfi"] - fit_configural_fit["cfi"]
delta_rmsea <- fit_metric_fit["rmsea"] - fit_configural_fit["rmsea"]

# Extract robust (scaled) fit indices
fit_configural_fit <- fitMeasures(fit_weak_rel_c, c("cfi.scaled", "rmsea.scaled"))
fit_metric_fit <- fitMeasures(fit_configural_rel_c, c("cfi.scaled", "rmsea.scaled"))

# Compute differences 
delta_cfi   <- fit_metric_fit["cfi.scaled"] - fit_configural_fit["cfi.scaled"]
delta_rmsea <- fit_metric_fit["rmsea.scaled"] - fit_configural_fit["rmsea.scaled"]

delta_cfi
delta_rmsea


# Strong invariance -------------------------------------------------------

strong_invar_rel_c <- '
########################################
#          FACTOR LOADINGS
########################################

# Wave 1 factors
eta1_1 =~ 1*tt1_cc2 + 
          lambda_i*tt1_cc3 + 
          lambda_e*tt1_cc4 +
          lambda_f*tt1_cc6

# Wave 1 factors
eta1_2 =~ 1*tt1_cu1.1 + 
          lambda_g*tt1_cu1.2 + 
          lambda_h*tt1_cu1.3 +
          lambda_j*tt1_cu2
          
eta1_3 =~ 1*tt1_le1.1 + 
          lambda_k*tt1_le1.3 + 
          lambda_l*tt1_le1.4 +
          lambda_m*tt1_le2          

# Wave 2 factors
eta2_1 =~ 1*tt2_cc2 + 
          lambda_i*tt2_cc3 + 
          lambda_e*tt2_cc4 + 
          lambda_f*tt2_cc6
          
# Wave 2 factors
eta2_2 =~ 1*tt2_cu1.1 + 
          lambda_g*tt2_cu1.2 + 
          lambda_h*tt2_cu1.3 + 
          lambda_j*tt2_cu2
          
eta2_3 =~ 1*tt2_le1.1 + 
          lambda_k*tt2_le1.3 + 
          lambda_l*tt2_le1.4 + 
          lambda_m*tt2_le2          

########################################
#     LATENT VARIABLE VARIANCES
########################################

eta1_1 ~~ eta1_1
eta1_2 ~~ eta1_2
eta1_3 ~~ eta1_3

eta2_1 ~~ eta2_1
eta2_2 ~~ eta2_2
eta2_3 ~~ eta2_3

########################################
#    LATENT VARIABLE COVARIANCES
########################################

# Within-wave covariances
eta1_1 ~~ eta1_2
eta1_2 ~~ eta1_3
eta1_1 ~~ eta1_3

eta2_1 ~~ eta2_2
eta2_2 ~~ eta2_3
eta2_1 ~~ eta2_3


# Cross-time covariances (same factor across times)
eta1_1 ~~ eta2_1
eta1_2 ~~ eta2_2
eta1_3 ~~ eta2_3

########################################
#      LATENT VARIABLE MEANS
########################################

eta1_1 ~ 0*1 #for scaling
eta1_2 ~ 1 #free
eta1_3 ~ 1 #free

eta2_1 ~ 1 #free
eta2_2 ~ 1 #free
eta2_3 ~ 1 #free

########################################
#   ITEM VARIANCES (THETA PARAM.)
########################################

tt1_cc2  ~~ 1*tt1_cc2
tt1_cc3  ~~ 1*tt1_cc3
tt1_cc4  ~~ 1*tt1_cc4
tt1_cc6  ~~ 1*tt1_cc6

tt2_cc2  ~~ 1*tt2_cc2
tt2_cc3  ~~ 1*tt2_cc3
tt2_cc4  ~~ 1*tt2_cc4
tt2_cc6  ~~ 1*tt2_cc6

tt1_cu1.1  ~~ 1*tt1_cu1.1
tt1_cu1.2  ~~ 1*tt1_cu1.2
tt1_cu1.3  ~~ 1*tt1_cu1.3
tt1_cu2   ~~ 1*tt1_cu2

tt2_cu1.1  ~~ 1*tt2_cu1.1
tt2_cu1.2  ~~ 1*tt2_cu1.2
tt2_cu1.3  ~~ 1*tt2_cu1.3
tt2_cu2   ~~ 1*tt2_cu2

tt1_le1.1  ~~ 1*tt1_le1.1
tt1_le1.3  ~~ 1*tt1_le1.3
tt1_le1.4  ~~ 1*tt1_le1.4
tt1_le2   ~~ 1*tt1_le2

tt2_le1.1  ~~ 1*tt2_le1.1
tt2_le1.3  ~~ 1*tt2_le1.3
tt2_le1.4  ~~ 1*tt2_le1.4
tt2_le2   ~~ 1*tt2_le2


########################################
#      THRESHOLDS (ORDERED ITEMS)
########################################

# Wave 1
tt1_cu1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt1_cu1.2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt1_cu1.3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3 + tau_e4*t4
tt1_cu2     | tau_f1*t1 + tau_f2*t2 + tau_f3*t3 + tau_f4*t4

tt1_le1.1   | tau_t1*t1 + tau_t2*t2 + tau_t3*t3 + tau_t4*t4
tt1_le1.3   | tau_g1*t1 + tau_g2*t2 + tau_g3*t3 + tau_g4*t4
tt1_le1.4   | tau_h1*t1 + tau_h2*t2 + tau_h3*t3 + tau_h4*t4
tt1_le2     | tau_j1*t1 + tau_j2*t2 + tau_j3*t3 + tau_j4*t4

tt1_cc2    | tau_u1*t1 + tau_u2*t2 + tau_u3*t3 + tau_u4*t4
tt1_cc3    | tau_k1*t1 + tau_k2*t2 + tau_k3*t3 + tau_k4*t4
tt1_cc4    | tau_l1*t1 + tau_l2*t2 + tau_l3*t3 + tau_l4*t4
tt1_cc6    | tau_m1*t1 + tau_m2*t2 + tau_m3*t3 + tau_m4*t4

# Wave 2
tt2_cu1.1   | tau_s1*t1 + tau_s2*t2 + tau_s3*t3 + tau_s4*t4
tt2_cu1.2   | tau_i1*t1 + tau_i2*t2 + tau_i3*t3 + tau_i4*t4
tt2_cu1.3   | tau_e1*t1 + tau_e2*t2 + tau_e3*t3
tt2_cu2     | tau_f1*t1 + tau_f2*t2 + tau_f3*t3

tt2_le1.1   | tau_t1*t1 + tau_t2*t2 + tau_t3*t3 + tau_t4*t4
tt2_le1.3   | tau_g1*t1 + tau_g2*t2 + tau_g3*t3 + tau_g4*t4
tt2_le1.4   | tau_h1*t1 + tau_h2*t2 + tau_h3*t3 + tau_h4*t4
tt2_le2     | tau_j1*t1 + tau_j2*t2 + tau_j3*t3 + tau_j4*t4

tt2_cc2    | tau_u1*t1 + tau_u2*t2 + tau_u3*t3 + tau_u4*t4
tt2_cc3    | tau_k1*t1 + tau_k2*t2 + tau_k3*t3 + tau_k4*t4
tt2_cc4    | tau_l1*t1 + tau_l2*t2 + tau_l3*t3 + tau_l4*t4
tt2_cc6    | tau_m1*t1 + tau_m2*t2 + tau_m3*t3 + tau_m4*t4

'

fit_strong_rel_c <- cfa(strong_invar_rel_c, 
                        estimator="dwls", 
                        test= "mv", 
                        data = utc_data, 
                        parameterization="theta", 
                        missing="pairwise",
                        ordered=TRUE)

# Model does not Converge. We therefore cannot establish strong factorial 
# invariance for the large related constructs mod. However weak factorial 
# invariance holds for the full multidimensional scale.


# 3. ICCs -----------------------------------------------------------------
# computing ICC for ordinal items by fitting a random intercept ordinal model
# using the cumulative link mixed model (clmm). Appropriate for ordinal data.

Total <- select(utc_data, # only dependent vars
                tt1_ty1, tt1_ty2,
                tt1_ty3, 
                tt1_ty5, tt1_ty8, tt1_ty7, 
                tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10,
                tt1_cu1.1:tt1_cu2,
                tt1_le1.1,
                tt1_le1.3,
                tt1_le1.4,
                tt1_le2,
                tt1_cc2:tt1_cc4, tt1_cc6
)

# Define your dataframe and cluster variable
cluster_var <- "tt1_scho6"  # cluster variable (school-level grouping)

# Add cluster variable to Total and keep its name
Total_with_cluster <- Total |>
  dplyr::mutate(tt1_scho6 = utc_data[[cluster_var]]) 


# Function to calculate ICC
calculate_icc <- function(data, item_var, cluster_var) {
  # Convert item to ordered factor if needed
  data[[item_var]] <- factor(data[[item_var]], ordered = TRUE)
  
  # Build formula with complete parentheses
  fmla <- reformulate(termlabels = paste0("(1|", cluster_var, ")"), response = item_var)
  
  # Try model fitting
  model <- try(clmm(fmla, data = data), silent = TRUE)
  
  # Handle errors
  if (inherits(model, "try-error")) {
    return(NA)
  }
  
  # Extract random effect variance
  var_cluster <- as.numeric(VarCorr(model)[[1]])
  icc <- var_cluster / (var_cluster + (pi^2 / 3))
  return(round(icc, 3))
}

# Loop over columns (automatically handles all columns)
icc_results <- sapply(names(Total_with_cluster), function(item) {
  # Exclude the cluster variable column from the items (to avoid errors)
  if (item != cluster_var) {
    calculate_icc(data = Total_with_cluster, item_var = item, cluster_var = cluster_var)
  } else {
    NA  # Skip cluster variable in the ICC calculation
  }
})

# Output table
icc_table <- data.frame(Item = names(Total_with_cluster), ICC = icc_results)
icc_table <- icc_table[!is.na(icc_table$ICC), ]  # Remove rows where ICC is NA (e.g., for non-item columns)
print(icc_table)

# Sort the ICC table by the ICC values in descending order
icc_table_sorted <- icc_table[order(icc_table$ICC, decreasing = TRUE), ]

# Print the sorted ICC table
print(icc_table_sorted)

# Vizualizing ICCs

# Create a bar plot of the ICC values
ggplot(icc_table_sorted, aes(x = reorder(Item, ICC), y = ICC)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_flip() +  # Flip the coordinates to make it horizontal
  labs(
    title = "ICC Values for Each Item",
    x = "Items",
    y = "ICC Value"
  ) +
  theme_minimal()

# alt viz
ggplot(icc_table_sorted, aes(x = reorder(Item, ICC), y = ICC)) +
  geom_bar(stat = "identity", fill = "lightcoral") +
  geom_text(aes(label = round(ICC, 3)), vjust = -0.3, size = 3.5) +  # Adding ICC values as text
  coord_flip() +  # Flip the coordinates
  labs(
    title = "ICC Values for Each Item",
    x = "Items",
    y = "ICC Value"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))




# 4. Reliability Analyses ----------------------------------------------------

# Collaboration types
#T1

# Using the model fit from CFA comparison as an initial check
compRelSEM(types_cfa_fit) # Note this is not appropriate for ESEMs as the crossloadings will distort it.

# Matrix-based approach using functions from psych() as main reliability analysis
types_rel_t1 <- select(utc_data, 
                       tt1_ty1, tt1_ty2,
                       tt1_ty3, 
                       tt1_ty5, tt1_ty8, tt1_ty7, 
                       tt1_ty9.1, tt1_ty9.3, tt1_ty9.4, tt1_ty10)

types_rel_t1_poly <- polychoric(types_rel_t1)$rho


# Restore dimnames from the original data
colnames(types_rel_t1_poly) <- colnames(types_rel_t1)
rownames(types_rel_t1_poly) <- colnames(types_rel_t1)

# Using non-deprecated functions from psych()
psych::omega(types_rel_t1_poly, nfactors = 3) 
psych::alpha(types_rel_t1_poly)

# Range inter-item correlations 
inter_item_vals <- types_rel_t1_poly[lower.tri(types_rel_t1_poly)]

range(inter_item_vals)
mean(inter_item_vals)  # Average inter-item correlation
median(inter_item_vals)  # Median inter-item correlation

#Item-total correlations
alpha_res <- psych::alpha(types_rel_t1_poly)
alpha_res$item.stats
item_total <- alpha_res$item.stats$r.cor
range(item_total)


# Variance explained
# Using alpha
alpha_res$total$std.alpha # standardized alpha


# T2

# Psych() functions
types_rel_t2 <- select(utc_data, 
                       tt2_ty1, tt2_ty2,
                       tt2_ty3, 
                       tt2_ty5, tt2_ty7, tt2_ty8,
                       tt2_ty9.1, tt2_ty9.3, tt2_ty9.4, tt2_ty10)

types_rel_t2_poly <- polychoric(types_rel_t2)$rho


# Restore dimnames from the original data
colnames(types_rel_t2_poly) <- colnames(types_rel_t2)
rownames(types_rel_t2_poly) <- colnames(types_rel_t2)

psych::omega(types_rel_t2_poly, nfactors = 3, n.obs = 389) # Warning of Heywood is not detected in neither ESEM nor in CFA comparison. We therefore ignore this warning as we conclude it is an artefact.
psych::alpha(types_rel_t2_poly)

# Range inter-item correlations 
inter_item_vals <- types_rel_t2_poly[lower.tri(types_rel_t2_poly)]

range(inter_item_vals)
mean(inter_item_vals)  # Average inter-item correlation
median(inter_item_vals)  # Median inter-item correlation

#Item-total correlations
alpha_res <- psych::alpha(types_rel_t2_poly)
alpha_res$item.stats
item_total <- alpha_res$item.stats$r.cor
range(item_total)

# Related constructs

#T1

# Using the model fit from CFA comparison as initial check (fit-based)
compRelSEM(rel_cfa_mod_fit)

# Matrix-based (main) approach
rel_rel_t1 <- select(utc_data, 
                     tt1_cc2, tt1_cc3, tt1_cc4, tt1_cc6,
                     tt1_cu1.1, tt1_cu1.2, tt1_cu1.3, 
                     tt1_le1.1, tt1_le1.3, tt1_le1.4, tt1_le2)

rel_rel_t1_poly <- polychoric(rel_rel_t1)$rho

# Restore dimnames from the original data
colnames(rel_rel_t1_poly) <- colnames(rel_rel_t1)
rownames(rel_rel_t1_poly) <- colnames(rel_rel_t1)

psych::omega(rel_rel_t1_poly, nfactors = 3) 
psych::alpha(rel_rel_t1_poly)

# Range inter-item correlations 
inter_item_vals <- rel_rel_t1_poly[lower.tri(rel_rel_t1_poly)]

range(inter_item_vals)
mean(inter_item_vals)  # Average inter-item correlation
median(inter_item_vals)  # Median inter-item correlation

#Item-total correlations
alpha_res <- psych::alpha(rel_rel_t1_poly)
alpha_res$item.stats
item_total <- alpha_res$item.stats$r.cor
range(item_total)


# Variance explained
# Using alpha
alpha_res$total$std.alpha # standardized alpha


# T2
rel_rel_t2 <- select(utc_data, 
                     tt2_cc2, tt2_cc3, tt2_cc4, tt2_cc6,
                     tt2_cu1.1, tt2_cu1.2, tt2_cu1.3, 
                     tt2_le1.1, tt2_le1.3, tt2_le1.4, tt2_le2)

rel_rel_t2_poly <- polychoric(rel_rel_t2)$rho

# Restore dimnames from the original data
colnames(rel_rel_t2_poly) <- colnames(rel_rel_t2)
rownames(rel_rel_t2_poly) <- colnames(rel_rel_t2)

psych::omega(rel_rel_t2_poly, nfactors = 3)
psych::alpha(rel_rel_t2_poly)


# Range inter-item correlations 
inter_item_vals <- rel_rel_t2_poly[lower.tri(rel_rel_t2_poly)]

range(inter_item_vals)
mean(inter_item_vals)  # Average inter-item correlation
median(inter_item_vals)  # Median inter-item correlation

#Item-total correlations
alpha_res <- psych::alpha(rel_rel_t2_poly)
alpha_res$item.stats
item_total <- alpha_res$item.stats$r.cor
range(item_total)

# Note that warnings of reversed items regards contrived collegiality vars.
# These are theoretically expected to be negatively correlated with the other
# factors. The warning is therefore not relevant. You may reverse code, 
# however interpretations are more complex and may appear counter intuitive if this is done. 