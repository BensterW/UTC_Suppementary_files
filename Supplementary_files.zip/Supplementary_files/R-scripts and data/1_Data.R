# Supplemental material for the article:
# "Unpacking Teacher Collaboration: Validation of Measurement Models Using
# Exploratory Structural Equation Modeling" by Waldejer B., Jensen M. T., 
# Solheim O. J.

# Scripts written by Waldejer B.
# For feedback or questions please send queries to the corresponding author's
# email: benjamin.waldejer@uis.no

# For users:
# Read the comments to see how and where to replace variable names. Use the 
# corresponding codebook for variables of interest. Note that LLMs are very 
# useful for troubleshooting code if something goes awry.

# Script 1 ----------------------------------------------------------------
# Information

# This script includes:
# 1. Data import
# 2. Descriptive sample stats
# 3. Data exploration
#   - Boxplots
#   - Correlation Plots
#   - Histograms
#   - Response patterns
#   - Multivariate normality test
# 4. Example of collapsed category dataframe


# Packages ----------------------------------------------------------------

library(readxl)
library(tidyverse)
library(psych)
library(corrplot)
library(misty)
library(discnorm)

# 1. Data importation -----------------------------------------------------

Sys.setlocale("LC_ALL", "nb-NO.UTF-8")
# This is in order to read Norwegian character strings present in the data set.

setsource() 

utc_data <- read_excel("Data/utc_data.xlsx")
View(utc_data)

# Required R-version to run script. If this prints "R version OK..." you may proceed.
# if not you must update to R version 4.1.0 as a minimum.
if (getRversion() < "4.1.0") {
  stop("This script requires R >= 4.1.0 (native pipe |> not supported in older versions).")
} else {
  message("R version OK: ", getRversion())
}

# Making sure values are numeric
utc_data <- utc_data |> 
  dplyr::mutate(across(where(is.character), ~ as.numeric(na_if(., ""))))

# check class
class(utc_data$tt1_ty1) # should print "numeric"

# The ID column from dataset has been replaced with a generic ID column as a 
# precaution to avoid identification of respondents.

# 2. Descriptive Sample Statistics ----------------------------------------
# Different options for obtaining descriptives

summary(utc_data)

# To see skew/kurtosis
describe(utc_data) 

sapply(utc_data, function(x) c(mean = mean(x, na.rm=TRUE),
                         sd = sd(x, na.rm=TRUE)))

# Number of respondents (observations)
nrow(utc_data)


# 3. Data Exploration -----------------------------------------------------

# Boxplots
# T1
boxplot(select(utc_data, 
               tt1_ty1) # replace with any var from codebook with prefix "tt1_"
)

# T2
boxplot(select(utc_data, 
               tt2_ty1) # replace with any var from codebook with prefix "tt2_"
)

# Correlation plots T1
# Note that we are using polychoric correlations of dependent vars

vars <- select(utc_data, tt1_fr1:tt1_cc6) # use the codebook to change selection of vars
pcor <- psych::polychoric(vars) # nb this takes some moments
poly_corr <- pcor$rho
corrplot(poly_corr, method = "number", type = "lower")

# Clustered plot
corrplot(cor(poly_corr, 
             use="complete.obs"), 
         order = "hclust", 
         tl.col='black', 
         tl.cex=.75
)

# Histograms
ggplot(data = utc_data,
       aes(x = as.numeric(as.character(tt1_cc6)))) + # Exchange "tt1_cc6" with any var from the codebook
  geom_histogram(binwidth = 1, na.rm = TRUE)

# Histogram of correlation values
cor_values <- poly_corr[lower.tri(poly_corr, diag = FALSE)] # Insert polychoric matrix

ggplot(data.frame(cor_values), aes(x = cor_values)) +
  geom_histogram(bins = 20, fill = "blue", alpha = 0.7, na.rm = TRUE) +
  labs(title = "Histogram of Polychoric Correlations",
       x = "Correlation Coefficient",
       y = "Frequency") +
  theme_minimal()

# Response Patterns and proportions

# Select variables
var_selection <- select(utc_data, tt1_ty1:tt1_ty10) # replace with any vars from codebook

# Compute proportions
proportions_list <- lapply(var_selection, function(var) {
  if (is.numeric(var)) var <- factor(var, levels = sort(unique(var)))
  prop.table(table(var))
})

# Convert to dataframe
proportions_df <- map_df(names(proportions_list), function(name) {
  data.frame(
    item = name,
    response = names(proportions_list[[name]]),
    proportion = as.numeric(proportions_list[[name]])
  )
})

# Order responses
proportions_df$response <- factor(proportions_df$response, levels = 1:5)

# Vizualise patterns with plot
ggplot(proportions_df, aes(x = item, y = proportion, fill = response)) + 
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_fill_brewer(palette = "Blues", direction = 1) +
  labs(
    title = "Response Distributions Across Items",
    x = "Item",
    y = "Proportion",
    fill = "Response"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
    panel.grid.major.x = element_blank()
  )


# Multivariate normality test
# Using the package discnorm() by Foldnes & Grønnestad (2020). Checks the assumption
# of underlying latent multivariate normality (0 is false 1 means assumption is met)

# Create selection for checking normality
bootTest_df <- select(utc_data, tt1_ty1:tt1_ty10) # Replace "tt1_ty1:tt1_ty10" with any vars from codebook

# Multivariate normality test (Foldnes & Grønnestad)
discnorm::bootTest(bootTest_df) 

